import { Spinner } from "./ui/spinner";

export function Loading() {
  return (
    <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50">
      <Spinner className="size-8 text-white" />
    </div>
  );
}
