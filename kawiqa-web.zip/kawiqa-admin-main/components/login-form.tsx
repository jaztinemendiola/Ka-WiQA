"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import useAuth from "@/context/AuthContext";
import { useState } from "react";
import { PasswordInput } from "./password-input";
import { Label } from "./ui/label";
import Link from "next/link";

export function LoginForm({
  className,
  ...props
}: React.ComponentProps<"div">) {
  const { login } = useAuth();
  const [loginForm, setLoginForm] = useState({
    email: "",
    password: "",
    agreeToPolicy: false,
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!loginForm.agreeToPolicy) return;

    await login(loginForm.email, loginForm.password);
  };

  return (
    <div className={cn("flex flex-col gap-6", className)} {...props}>
      <Card>
        <CardHeader>
          <CardTitle>Login to your account</CardTitle>
          <CardDescription>
            Enter your email below to login to your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin}>
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="email">Email</FieldLabel>
                <Input
                  id="email"
                  type="email"
                  placeholder="m@example.com"
                  required
                  value={loginForm.email}
                  onChange={e =>
                    setLoginForm(prev => ({
                      ...prev,
                      email: e.target.value,
                    }))
                  }
                />
              </Field>

              <Field>
                <FieldLabel htmlFor="password">Password</FieldLabel>
                <PasswordInput
                  value={loginForm.password}
                  onChange={e =>
                    setLoginForm(prev => ({
                      ...prev,
                      password: e.target.value,
                    }))
                  }
                  required
                />
              </Field>

              {/* Privacy Policy Agreement */}
              <Field>
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="privacy"
                    checked={loginForm.agreeToPolicy}
                    onCheckedChange={checked =>
                      setLoginForm(prev => ({
                        ...prev,
                        agreeToPolicy: checked === true,
                      }))
                    }
                  />
                  <Label
                    htmlFor="privacy"
                    className="text-sm leading-snug text-muted-foreground">
                    I agree to the{" "}
                    <Link
                      href="/privacy-policy"
                      target="_blank"
                      className="underline underline-offset-4 hover:text-primary">
                      Privacy Policy
                    </Link>
                  </Label>
                </div>
              </Field>

              <Field>
                <Button type="submit" disabled={!loginForm.agreeToPolicy}>
                  Login
                </Button>
              </Field>
            </FieldGroup>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
