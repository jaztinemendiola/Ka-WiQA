"use client";

import { version } from "../package.json";
import * as React from "react";
import {
  AudioWaveform,
  BookOpen,
  BookOpenCheck,
  Bot,
  Command,
  GalleryVerticalEnd,
  Home,
  Images,
  Lightbulb,
  Link2,
  Logs,
  Settings2,
  Speech,
  SpellCheck,
  SquareTerminal,
  Tags,
  Users,
  UsersRound,
} from "lucide-react";

import { NavUser } from "@/components/nav-user";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@/components/ui/sidebar";
import { Field } from "./ui/field";
import { NavManagements } from "./nav-managements";
import { NavUsers } from "./nav-users";
import { NavGames } from "./nav-games";
import { usePathname } from "next/navigation";
import { NavOthers } from "./nav-others";
import { useAuthStore } from "@/stores/auth";

// This is sample data.
const data = {
  user: {
    name: "shadcn",
    email: "m@example.com",
    avatar: "/avatars/shadcn.jpg",
  },
  navHeader: {
    name: "Kawiqa | Admin",
  },
  teams: [
    {
      name: "Acme Inc",
      logo: GalleryVerticalEnd,
      plan: "Enterprise",
    },
    {
      name: "Acme Corp.",
      logo: AudioWaveform,
      plan: "Startup",
    },
    {
      name: "Evil Corp.",
      logo: Command,
      plan: "Free",
    },
  ],
  navMain: [
    {
      title: "Playground",
      url: "#",
      icon: SquareTerminal,
      isActive: true,
      items: [
        {
          title: "History",
          url: "#",
        },
        {
          title: "Starred",
          url: "#",
        },
        {
          title: "Settings",
          url: "#",
        },
      ],
    },
    {
      title: "Models",
      url: "#",
      icon: Bot,
      items: [
        {
          title: "Genesis",
          url: "#",
        },
        {
          title: "Explorer",
          url: "#",
        },
        {
          title: "Quantum",
          url: "#",
        },
      ],
    },
    {
      title: "Documentation",
      url: "#",
      icon: BookOpen,
      items: [
        {
          title: "Introduction",
          url: "#",
        },
        {
          title: "Get Started",
          url: "#",
        },
        {
          title: "Tutorials",
          url: "#",
        },
        {
          title: "Changelog",
          url: "#",
        },
      ],
    },
    {
      title: "Settings",
      url: "#",
      icon: Settings2,
      items: [
        {
          title: "General",
          url: "#",
        },
        {
          title: "Team",
          url: "#",
        },
        {
          title: "Billing",
          url: "#",
        },
        {
          title: "Limits",
          url: "#",
        },
      ],
    },
  ],
  managements: [
    {
      name: "Home",
      url: "/app/home",
      icon: Home,
    },
    {
      name: "Categories",
      url: "/app/categories",
      icon: Tags,
    },
    {
      name: "Vocabularies",
      url: "/app/vocabulary",
      icon: BookOpen,
    },
    {
      name: "Word of the Day",
      url: "/app/word-of-the-day",
      icon: Lightbulb,
    },
    {
      name: "Pronunciations",
      url: "/app/pronunciations",
      icon: Speech,
    },
  ],
   users: [
     {
       name: "Students",
       url: "/app/students",
       icon: Users,
     },
     {
       name: "Teachers",
       url: "/app/teachers",
       icon: UsersRound,
     },
     {
       name: "Assign Students",
       url: "/app/teachers/assign-students",
       icon: Link2,
     },
     {
       name: "Grades Management",
       url: "/app/grades",
       icon: BookOpenCheck,
     },
   ],
  games: [
    {
      name: "Spelling",
      url: "/app/games/spelling",
      icon: SpellCheck,
    },
    {
      name: "2 pics 1/2 words",
      url: "/app/games/two-pics",
      icon: Images,
    },
  ],
  others: [
    {
      name: "Audit Logs",
      url: "/app/logs",
      icon: Logs,
    },
  ],
};

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname();
  const { isTeacher } = useAuthStore();

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader className="self-center p-4">
        {/* <TeamSwitcher teams={data.teams} /> */}
        <Field className="font-bold group-data-[collapsible=icon]:hidden">
          KA-WIQA | {isTeacher ? "Teacher" : "Admin"}
        </Field>
      </SidebarHeader>
      <SidebarContent>
        {/* <NavMain items={data.navMain} /> */}
        <NavManagements managements={data.managements} currentPath={pathname} />
        <NavGames games={data.games} currentPath={pathname} />
        <NavUsers
          users={
            isTeacher
              ? data.users.filter(user => !["Teachers", "Assign Students"].includes(user.name))
              : data.users
          }
          currentPath={pathname}
        />
        <NavOthers others={data.others} currentPath={pathname} />
      </SidebarContent>
      <SidebarFooter>
        <NavUser />

        <div className="text-muted-foreground text-xs text-right flex justify-between px-4">
          <p>Version:</p>
          <p>{version}</p>
        </div>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
