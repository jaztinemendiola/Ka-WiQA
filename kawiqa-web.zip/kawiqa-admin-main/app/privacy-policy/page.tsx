import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

export default function PrivacyPolicyPage() {
  return (
    <div className="flex justify-center">
      <div className="max-w-5xl py-10 px-5 space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl">
              Privacy Policy for KA-WIQA
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Effective Date: <span className="italic">January 01, 2026</span>
            </p>
            <div className="flex gap-2 pt-2">
              <Badge variant="secondary">RA 10173</Badge>
              <Badge variant="secondary">NPC Aligned</Badge>
              <Badge variant="secondary">Child-Focused</Badge>
            </div>
          </CardHeader>

          <CardContent className="space-y-6 text-muted-foreground">
            <p>
              KA-WIQA (&quot;we,&quot; &quot;us,&quot; or &quot;our&quot;) is
              committed to protecting the privacy and personal data of our
              users. This Privacy Policy explains how personal information is
              collected, used, stored, disclosed, and protected in compliance
              with the Data Privacy Act of 2012 (Republic Act No. 10173) of the
              Philippines.
            </p>

            <p>This policy applies to:</p>
            <ul className="list-disc pl-6">
              <li>
                KA-WIQA Mobile Application (students and parents/guardians)
              </li>
              <li>
                KA-WIQA Admin Web Application (administrators and teachers)
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Main Sections */}
        <Accordion type="multiple" className="w-full">
          {/* 1 */}
          <AccordionItem value="item-1">
            <AccordionTrigger>1. Information We Collect</AccordionTrigger>
            <AccordionContent className="space-y-4">
              <div>
                <h4 className="font-semibold">a. Personal Information</h4>
                <ul className="list-disc pl-6 text-muted-foreground">
                  <li>
                    Name (student, parent/guardian, teacher, administrator)
                  </li>
                  <li>Age or grade level</li>
                  <li>Email address or contact information</li>
                  <li>Username and login credentials</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold">
                  b. Usage and Technical Information
                </h4>
                <ul className="list-disc pl-6 text-muted-foreground">
                  <li>App usage data and learning activities</li>
                  <li>Device type and operating system</li>
                  <li>System logs for security and administration</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold">c. Children’s Information</h4>
                <p className="text-muted-foreground">
                  KA-WIQA is designed for children in Grades 1 to 4. Personal
                  data of minors is collected only with parental or legal
                  guardian consent.
                </p>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* 2 */}
          <AccordionItem value="item-2">
            <AccordionTrigger>2. Purpose of Data Collection</AccordionTrigger>
            <AccordionContent>
              <ul className="list-disc pl-6 text-muted-foreground space-y-1">
                <li>Provide access to educational content</li>
                <li>Monitor learning progress</li>
                <li>Manage user and administrative accounts</li>
                <li>Improve system performance and experience</li>
                <li>Comply with legal and academic requirements</li>
              </ul>
            </AccordionContent>
          </AccordionItem>

          {/* 3 */}
          <AccordionItem value="item-3">
            <AccordionTrigger>3. Data Sharing and Disclosure</AccordionTrigger>
            <AccordionContent className="text-muted-foreground space-y-2">
              <p>KA-WIQA does not sell, rent, or trade personal information.</p>
              <ul className="list-disc pl-6">
                <li>Authorized administrators and teachers</li>
                <li>Legal or government requirements</li>
                <li>Protection of system and user safety</li>
              </ul>
            </AccordionContent>
          </AccordionItem>

          {/* 4 */}
          <AccordionItem value="item-4">
            <AccordionTrigger>4. Data Protection & Security</AccordionTrigger>
            <AccordionContent>
              <ul className="list-disc pl-6 text-muted-foreground space-y-1">
                <li>Secure authentication and access control</li>
                <li>Encrypted storage and transmission</li>
                <li>Restricted personnel access</li>
                <li>Regular system monitoring</li>
              </ul>
            </AccordionContent>
          </AccordionItem>

          {/* 5 */}
          <AccordionItem value="item-5">
            <AccordionTrigger>5. Data Retention</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              Personal data is retained only as long as necessary and is
              securely deleted or anonymized when no longer required.
            </AccordionContent>
          </AccordionItem>

          {/* 6 */}
          <AccordionItem value="item-6">
            <AccordionTrigger>6. User Rights</AccordionTrigger>
            <AccordionContent>
              <ul className="list-disc pl-6 text-muted-foreground space-y-1">
                <li>Right to be informed</li>
                <li>Right to access and correction</li>
                <li>Right to object to processing</li>
                <li>Right to deletion or blocking</li>
                <li>Right to file a complaint with the NPC</li>
              </ul>
            </AccordionContent>
          </AccordionItem>

          {/* 7 */}
          <AccordionItem value="item-7">
            <AccordionTrigger>7. Consent</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              By using KA-WIQA, users and parents/guardians consent to the
              collection and processing of personal data. Parental consent is
              required for minors.
            </AccordionContent>
          </AccordionItem>

          {/* 8 */}
          <AccordionItem value="item-8">
            <AccordionTrigger>8. Changes to This Policy</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">
              KA-WIQA may update this policy and will notify users of
              significant changes through official channels.
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        {/* In-App Privacy Notice */}
        <Card>
          <CardHeader>
            <CardTitle>In-App Privacy Notice (Short Version)</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground space-y-2">
            <p>
              KA-WIQA respects your privacy and complies with RA 10173. We
              collect only necessary personal data to provide educational
              services such as vocabulary learning and pronunciation practice.
            </p>
            <p>
              Parents or guardians must provide consent for minors. Users may
              access, correct, or request deletion of their data.
            </p>
          </CardContent>
        </Card>

        {/* Compliance */}
        <Card>
          <CardHeader>
            <CardTitle>Compliance Statements</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground space-y-3">
            <p>
              This Privacy Policy follows NPC principles of Transparency,
              Legitimate Purpose, and Proportionality.
            </p>
            <p>
              KA-WIQA complies with Google Play Developer Policy and Apple App
              Store Privacy Guidelines. Children’s data is protected and never
              sold or used for advertising.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
