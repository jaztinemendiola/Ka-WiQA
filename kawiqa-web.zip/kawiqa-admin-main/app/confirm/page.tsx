"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle2 } from "lucide-react";
import { supabase } from "@/lib/supabase/client";

function decodeJWT(token: string) {
  const payload = token.split(".")[1]; // second part
  const decoded = atob(payload); // base64 decode
  return JSON.parse(decoded);
}
export default function ConfirmSignupPage() {
  const [loading, setLoading] = useState(true);
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Extract access_token from URL hash
    const hash = window.location.hash; // "#access_token=..."
    const params = new URLSearchParams(hash.slice(1));
    const token = params.get("access_token");
    const refresh = params.get("refresh_token");
    console.log(token, refresh);

    if (!token && !refresh) {
      setError("No access token found in URL.");
      setLoading(false);
      return;
    }

    // Set Supabase session using the token
    const confirmUser = async () => {
      try {
        // This sets the session so supabase client knows the user is logged in
        const { data, error: sessionError } = await supabase.auth.setSession({
          access_token: token!,
          refresh_token: refresh!,
        });

        if (sessionError) {
          setError(sessionError.message);
        } else {
          setConfirmed(true);
        }
      } catch (err: any) {
        setError(err.message || "Something went wrong.");
      } finally {
        setLoading(false);
      }
    };

    confirmUser();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted px-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <CardTitle>Email confirmation</CardTitle>
          <CardDescription>We’re verifying your email address</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {loading && (
            <div className="flex flex-col items-center gap-2">
              <Loader2 className="h-6 w-6 animate-spin" />
              <p className="text-sm text-muted-foreground">
                Confirming your email…
              </p>
            </div>
          )}

          {!loading && error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {!loading && confirmed && (
            <div className="flex flex-col items-center gap-3">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
              <p className="text-sm text-muted-foreground">
                Your email has been confirmed. You can now log in to the app.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
