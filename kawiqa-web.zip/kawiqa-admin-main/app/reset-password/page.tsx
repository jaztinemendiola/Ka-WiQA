"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, Loader2 } from "lucide-react";
import { supabase } from "@/lib/supabase/client";
import { PasswordInput } from "@/components/password-input";
import { toast } from "sonner";

export default function ResetPasswordPage() {
  const router = useRouter();

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [success, setSuccess] = useState(false);

  // Ensure this page is opened via Supabase recovery link
  // useEffect(() => {
  //   supabase.auth
  //     .getSession()
  //     .then(({ data }) => {
  //       console.log(data);

  //       if (!data.session) {
  //         setError("This reset link is invalid or has expired.");
  //       } else {
  //         setReady(true);
  //       }
  //     })
  //     .catch(data => console.error(data));
  // }, []);

  useEffect(() => {
    // Extract access_token from URL hash
    const hash = window.location.hash; // "#access_token=..."
    const params = new URLSearchParams(hash.slice(1));
    const token = params.get("access_token");
    const refresh = params.get("refresh_token");

    if (!token && !refresh) {
      setError("No access token found in URL.");
      setLoading(false);
      return;
    }

    // Set Supabase session using the token
    const setSession = async () => {
      try {
        const { error } = await supabase.auth.setSession({
          access_token: token!,
          refresh_token: refresh!,
        });

        if (error) {
          throw error;
        }

        setReady(true);
      } catch (err: any) {
        setError(err.message || "Something went wrong.");
      } finally {
        setLoading(false);
      }
    };

    setSession();
  }, []);

  const handleResetPassword = async () => {
    setError(null);

    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);

    const { error } = await supabase.auth.updateUser({
      password,
    });

    setLoading(false);

    if (error) {
      setError(error.message);
    } else {
      toast.success("Password updated successfully!");
      setReady(false);
      setSuccess(true);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Reset your password</CardTitle>
          <CardDescription>
            Enter a new password for your account
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="flex flex-col items-center space-y-2">
              <CheckCircle2 className="h-20 w-20 text-green-600" />
              <AlertDescription className="text-center">
                Your password has been updated successfully!
              </AlertDescription>
            </Alert>
          )}

          {ready && !success && (
            <>
              <div className="space-y-2">
                <Label htmlFor="password">New password</Label>
                <PasswordInput
                  id="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm password</Label>
                <PasswordInput
                  id="confirmPassword"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  required
                />
              </div>

              <Button
                className="w-full"
                onClick={handleResetPassword}
                disabled={loading}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Update password
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
