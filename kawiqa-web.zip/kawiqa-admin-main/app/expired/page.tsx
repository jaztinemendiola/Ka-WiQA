import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail } from "lucide-react";

export default function ExpiredPage() {
  const contactEmail =
    process.env.NEXT_PUBLIC_CONTACT_EMAIL || "support@kawiqa.com";

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-red-600">
            Deployment Expired
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-center text-gray-600">
            This deployment has expired and is no longer active. If you wish to
            continue using this service, please contact the author/developer.
          </p>

          {/* <div className="flex items-center justify-center gap-2 text-gray-600">
            <Mail className="w-4 h-4" />
            <a
              href={`mailto:${contactEmail}`}
              className="text-blue-600 hover:underline">
              {contactEmail}
            </a>
          </div> */}

          <div className="text-center text-sm text-gray-500 mt-4">
            <p>Thank you for using our service.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
