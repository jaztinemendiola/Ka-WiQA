import { createClient } from "@/lib/supabase/server"

export async function GET() {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("profiles")
    .select("id, fullname, email")
    .order("fullname", { ascending: true })

  if (error) {
    console.error("Error fetching users:", error)
    return new Response(JSON.stringify({ error: "Failed to fetch users" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }

  return new Response(JSON.stringify(data || []), {
    headers: { "Content-Type": "application/json" },
  })
}
