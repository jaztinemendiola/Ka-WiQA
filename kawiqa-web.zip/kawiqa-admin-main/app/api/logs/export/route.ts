import { createClient } from "@/lib/supabase/server";
import { format } from "date-fns";

export async function GET(request: Request) {
  const supabase = await createClient();
  const { searchParams } = new URL(request.url);

  // Build query with filters
  let query = supabase
    .from("audit_logs_v2")
    .select(`*, user:profiles!audit_logs_v2_actor_user_id_fkey(fullname)`)
    .order("created_at", { ascending: false });

  // Apply filters
  const userId = searchParams.get("user");
  if (userId) {
    query = query.eq("actor_user_id", userId);
  }

  const tableName = searchParams.get("module");
  if (tableName) {
    query = query.eq("module", tableName);
  }

  const search = searchParams.get("search");
  if (search) {
    query = query.or(`description.ilike.%${search}%,action.ilike.%${search}%`);
  }

  const from = searchParams.get("from");
  if (from) {
    query = query.gte("created_at", `${from}T00:00:00`);
  }

  const to = searchParams.get("to");
  if (to) {
    query = query.lte("created_at", `${to}T23:59:59`);
  }

  const { data, error } = await query;

  if (error) {
    console.error("Error fetching logs for export:", error);
    return new Response(JSON.stringify({ error: "Failed to fetch logs" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  // Generate CSV
  const headers = [
    "Date",
    "User",
    "Action",
    "Table",
    "Record ID",
    "Description",
    "IP Address",
  ];

  const rows = (data || []).map(log => [
    format(new Date(log.created_at), "yyyy-MM-dd HH:mm:ss"),
    log.user?.fullname || "System",
    log.action,
    log.table_name || "",
    log.record_id || "",
    `"${(log.description || "").replace(/"/g, '""')}"`,
    log.ip_address || "",
  ]);

  const csv = [headers, ...rows].map(row => row.join(",")).join("\n");

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="audit-logs-${new Date().toISOString().split("T")[0]}.csv"`,
    },
  });
}
