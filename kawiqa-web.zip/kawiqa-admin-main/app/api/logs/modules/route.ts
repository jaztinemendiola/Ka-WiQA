import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("audit_logs_v2")
    .select("module")
    .not("module", "is", null)
    .order("module", { ascending: true });

  if (error) {
    console.error("Error fetching modules:", error);
    return new Response(JSON.stringify({ error: "Failed to fetch modules" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  // Extract unique table names (used as module names)
  const uniqueModules = Array.from(
    new Set((data || []).map(log => log.module).filter(Boolean)),
  ).map(module => ({ module }));

  return new Response(JSON.stringify(uniqueModules), {
    headers: { "Content-Type": "application/json" },
  });
}
