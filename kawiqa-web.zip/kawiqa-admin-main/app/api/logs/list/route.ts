import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const supabase = await createClient();
  const { searchParams } = new URL(request.url);

  const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
  const limit = Math.min(parseInt(searchParams.get("limit") || "50"), 100);
  const start = (page - 1) * limit;
  const end = start + limit - 1;

  let query = supabase
    .from("audit_logs_v2")
    .select(`*, user:profiles!audit_logs_v2_actor_user_id_fkey(fullname)`, {
      count: "exact",
    })
    .order("created_at", { ascending: false });

  // Apply filters
  const user = searchParams.get("user");
  if (user) {
    query = query.eq("actor_user_id", user);
  }

  const moduleParam = searchParams.get("module");
  if (moduleParam) {
    query = query.eq("module", moduleParam);
  }

  const search = searchParams.get("search");
  if (search) {
    query = query.or(`description.ilike.%${search}%,action.ilike.%${search}%`);
  }

  const from = searchParams.get("from");
  if (from) {
    query = query.gte("created_at", `${from}T00:00:00`);
  }

  const to = searchParams.get("to");
  if (to) {
    query = query.lte("created_at", `${to}T23:59:59`);
  }

  const status = searchParams.get("status");
  if (status) {
    query = query.eq("status", status);
  }

  const { data, count, error } = await query.range(start, end);

  if (error) {
    console.error("Error fetching logs:", error);
    return new Response(JSON.stringify({ error: "Failed to fetch logs" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  return new Response(
    JSON.stringify({
      logs: data || [],
      totalCount: count || 0,
      page,
      totalPages: Math.ceil((count || 0) / limit),
    }),
    {
      headers: { "Content-Type": "application/json" },
    },
  );
}
