import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

async function logAuditEvent(
  action: string,
  target_user_id?: string,
  description?: string,
  actor_user_id?: string,
) {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
  );

  await supabase.rpc("log_audit_event", {
    p_actor_id: actor_user_id || null,
    p_target_user_id: target_user_id || null,
    p_action: action,
    p_module: "users",
    p_page: "/app/users",
    p_status: "success",
    p_description: description || null,
    p_ip: null,
    p_user_agent: null,
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email, password, role, user_metadata, actor_user_id } = body;

    if (!email || !role) {
      return NextResponse.json(
        { error: "Email and role are required" },
        { status: 400 },
      );
    }

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
    );

    let authData;

    if (!password) {
      const { data, error: inviteError } =
        await supabase.auth.admin.inviteUserByEmail(email, {
          data: user_metadata || { role },
          redirectTo: "https://kawiqa-admin.vercel.app/",
        });

      if (inviteError) {
        console.error("Invite user error:", inviteError);
        return NextResponse.json(
          { error: inviteError.message },
          { status: 400 },
        );
      }
      authData = data;
      await logAuditEvent(
        "INVITE",
        authData.user.id,
        `User invited: ${email}`,
        actor_user_id,
      );
    } else {
      const { data, error: authError } = await supabase.auth.admin.createUser({
        email,
        password,
        user_metadata: user_metadata || { role },
        email_confirm: false,
      });

      await supabase.auth.admin.inviteUserByEmail(email, {
        data: user_metadata || { role },
        redirectTo: "https://kawiqa-admin.vercel.app/",
      });

      if (authError) {
        console.error("Create user error:", authError);
        return NextResponse.json({ error: authError.message }, { status: 400 });
      }
      authData = data;
      await logAuditEvent(
        "INSERT",
        authData.user.id,
        `User invited: ${email}`,
        actor_user_id,
      );
    }

    if (!authData?.user) {
      return NextResponse.json(
        { error: "User creation failed" },
        { status: 400 },
      );
    }

    await logAuditEvent(
      "INSERT",
      authData.user.id,
      `User created: ${email}`,
      actor_user_id,
    );

    return NextResponse.json({ user: authData.user }, { status: 201 });
  } catch (error) {
    console.error("Error creating user:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { email, actor_user_id } = body;

    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 });
    }

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
    );

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: "https://kawiqa-admin.vercel.app/reset-password",
    });

    if (error) {
      console.error("Reset password error:", error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json(
      { message: "Reset password email sent" },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error sending reset password email:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { userId, email, password } = body;

    if (!userId) {
      return NextResponse.json(
        { error: "User ID is required" },
        { status: 400 },
      );
    }

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
    );

    const updateData: Record<string, unknown> = {};

    if (email) {
      updateData.email = email;
    }
    if (password) {
      updateData.password = password;
    }

    const { data, error } = await supabase.auth.admin.updateUserById(
      userId,
      updateData,
    );

    if (error) {
      console.error("Update user error:", error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    await logAuditEvent("UPDATE", userId, `User updated`);

    return NextResponse.json({ user: data.user }, { status: 200 });
  } catch (error) {
    console.error("Error updating user:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
