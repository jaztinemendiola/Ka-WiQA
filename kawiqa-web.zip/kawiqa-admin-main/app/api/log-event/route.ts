import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const getIP = async () => {
  const res = await fetch("https://api.ipify.org?format=json");
  const data = await res.json();
  return data.ip || "";
};

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      actor_user_id,
      target_user_id,
      action,
      module,
      page,
      status,
      description,
      ip_address,
      user_agent,
    } = body;

    if (!action) {
      return NextResponse.json({ error: "Missing action" }, { status: 400 });
    }

    const clientIP = ip_address || (await getIP());

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
    );

    const { error } = await supabase.rpc("log_audit_event", {
      p_actor_id: actor_user_id || null,
      p_target_user_id: target_user_id || null,
      p_action: action,
      p_module: module || null,
      p_page: page || null,
      p_status: status || "success",
      p_description: description || null,
      p_ip: clientIP,
      p_user_agent: user_agent || null,
    });

    if (error) throw error;

    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}
