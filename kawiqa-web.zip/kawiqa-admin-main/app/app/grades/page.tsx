"use client";

import { useEffect, useState } from "react";
import { useGrades } from "./hooks/useGrades";
import { Button } from "@/components/ui/button";
import { GradeDialog } from "./components/GradeDialog";
import { SectionDialog } from "./components/SectionDialog";
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Trash2, Plus, Inbox } from "lucide-react";

export default function GradesPage() {
  const {
    grades,
    sections,
    createGrade,
    updateGrade,
    deleteGrade,
    createSection,
    updateSection,
    deleteSection,
    fetchGrades,
    fetchSections,
  } = useGrades();

  const [gradeDialog, setGradeDialog] = useState(false);
  const [sectionDialog, setSectionDialog] = useState(false);

  const [gradeName, setGradeName] = useState("");
  const [editingGrade, setEditingGrade] = useState<number | null>(null);

  const [sectionName, setSectionName] = useState("");
  const [sectionGrade, setSectionGrade] = useState<number | null>(null);
  const [editingSection, setEditingSection] = useState<number | null>(null);

  const handleSaveGrade = async () => {
    if (editingGrade) {
      await updateGrade(editingGrade, gradeName);
    } else {
      await createGrade(gradeName);
    }
    setGradeDialog(false);
    setEditingGrade(null);
    setGradeName("");
  };

  const handleSaveSection = async () => {
    if (!sectionGrade) return;
    if (editingSection) {
      await updateSection(editingSection, sectionName);
    } else {
      await createSection(sectionGrade, sectionName);
    }
    setSectionDialog(false);
    setEditingSection(null);
    setSectionName("");
    setSectionGrade(null);
  };

  useEffect(() => {
    fetchGrades();
    fetchSections();
  }, []);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 w-full gap-4 p-4">
      {/* GRADES CARD */}
      <Card className="w-full shadow-sm flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl font-semibold">Grades</CardTitle>
          <Button onClick={() => setGradeDialog(true)}>
            <Plus className="size-4 mr-2" /> Add Grade
          </Button>
        </CardHeader>

        <CardContent className="flex flex-col flex-grow">
          {grades.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
              <Inbox className="size-10 mb-2" />
              <p>No grades found</p>
            </div>
          ) : (
            <div className="overflow-hidden rounded border">
              <table className="w-full text-sm">
                <thead className="bg-muted">
                  <tr>
                    <th className="p-3 text-left">Name</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {grades.map(g => (
                    <tr key={g.id} className="border-t">
                      <td className="p-3">{g.name}</td>
                      <td className="p-3">
                        <div className="flex items-center justify-center gap-3">
                          <Button
                            size="sm"
                            onClick={() => {
                              setEditingGrade(g.id);
                              setGradeName(g.name);
                              setGradeDialog(true);
                            }}>
                            Edit
                          </Button>

                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" size="sm">
                                Delete
                              </Button>
                            </AlertDialogTrigger>

                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <div className="flex items-center gap-2">
                                  <Trash2 className="size-5 text-destructive" />
                                  <AlertDialogTitle>Delete</AlertDialogTitle>
                                </div>
                                <AlertDialogDescription>
                                  This will permanently delete. This action
                                  cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>

                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  className="bg-destructive text-white hover:bg-destructive/90"
                                  onClick={() => deleteGrade(g.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* SECTIONS CARD */}
      <Card className="w-full shadow-sm flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl font-semibold">Sections</CardTitle>
          <Button onClick={() => setSectionDialog(true)}>
            <Plus className="size-4 mr-2" /> Add Section
          </Button>
        </CardHeader>

        <CardContent className="flex flex-col flex-grow">
          {sections.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
              <Inbox className="size-10 mb-2" />
              <p>No sections found</p>
            </div>
          ) : (
            <div className="overflow-hidden rounded border">
              <table className="w-full text-sm">
                <thead className="bg-muted">
                  <tr>
                    <th className="p-3 text-left">Section</th>
                    <th className="p-3 text-left">Grade</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sections.map(s => {
                    const grade = grades.find(g => g.id === s.grade_id);
                    return (
                      <tr key={s.id} className="border-t">
                        <td className="p-3">{s.name}</td>
                        <td className="p-3">{grade?.name}</td>
                        <td className="p-3">
                          <div className="flex items-center justify-center gap-3">
                            <Button
                              size="sm"
                              onClick={() => {
                                setEditingSection(s.id);
                                setSectionName(s.name);
                                setSectionGrade(s.grade_id);
                                setSectionDialog(true);
                              }}>
                              Edit
                            </Button>

                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="destructive" size="sm">
                                  Delete
                                </Button>
                              </AlertDialogTrigger>

                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <div className="flex items-center gap-2">
                                    <Trash2 className="size-5 text-destructive" />
                                    <AlertDialogTitle>Delete</AlertDialogTitle>
                                  </div>
                                  <AlertDialogDescription>
                                    This will permanently delete. This action
                                    cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>

                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-destructive text-white hover:bg-destructive/90"
                                    onClick={() => deleteSection(s.id)}>
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* DIALOGS */}
      <GradeDialog
        open={gradeDialog}
        onOpenChange={setGradeDialog}
        value={gradeName}
        onChange={setGradeName}
        onSave={handleSaveGrade}
      />

      <SectionDialog
        open={sectionDialog}
        onOpenChange={setSectionDialog}
        gradeId={sectionGrade}
        name={sectionName}
        onGradeChange={setSectionGrade}
        onNameChange={setSectionName}
        onSave={handleSaveSection}
        grades={grades}
      />
    </div>
  );
}
