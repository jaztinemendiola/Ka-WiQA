"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectTrigger,
  SelectItem,
  SelectValue,
  SelectContent,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Grade } from "../hooks/useGrades";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  gradeId: number | null;
  name: string;
  onGradeChange: (id: number) => void;
  onNameChange: (name: string) => void;
  onSave: () => void;
  grades: Grade[];
}

export const SectionDialog = ({
  open,
  onOpenChange,
  gradeId,
  name,
  onGradeChange,
  onNameChange,
  onSave,
  grades,
}: Props) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Section</DialogTitle>
        </DialogHeader>

        <Select
          value={String(gradeId ?? "")}
          onValueChange={v => onGradeChange(Number(v))}>
          <SelectTrigger>
            <SelectValue placeholder="Select grade" />
          </SelectTrigger>
          <SelectContent>
            {grades.map(g => (
              <SelectItem key={g.id} value={String(g.id)}>
                {g.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Input
          placeholder="Section name"
          value={name}
          onChange={e => onNameChange(e.target.value)}
        />

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={onSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
