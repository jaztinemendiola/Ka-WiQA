"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase/client";
import { toast } from "sonner";
import useAuditLogs from "@/hooks/useAuditLogs";

export interface Grade {
  id: number;
  name: string;
}

export interface Section {
  id: number;
  grade_id: number;
  name: string;
}

export const useGrades = () => {
  const [grades, setGrades] = useState<Grade[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [isLoading, setLoading] = useState(false);
  const { logEvent } = useAuditLogs();

  const fetchGrades = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("grades")
      .select("*")
      .order("id");
    if (error) toast.error("Unable to load grades");
    setGrades(data || []);
    setLoading(false);
  };

  const fetchSections = async () => {
    const { data, error } = await supabase
      .from("sections")
      .select("*")
      .order("grade_id");
    if (error) toast.error("Unable to load sections");
    setSections(data || []);
  };

  const createGrade = async (name: string) => {
    const { error } = await supabase.from("grades").insert({ name });
    if (error) {
      toast.error("Failed to create grade");
      throw error;
    }
    toast.success("Grade added");
    await logEvent("INSERT", undefined, "grades", window.location.pathname, "success", `Created grade: ${name}`);
    fetchGrades();
  };

  const updateGrade = async (id: number, name: string) => {
    const { error } = await supabase
      .from("grades")
      .update({ name })
      .eq("id", id);
    if (error) {
      toast.error("Failed to update grade");
      throw error;
    }
    toast.success("Grade updated");
    await logEvent("UPDATE", undefined, "grades", window.location.pathname, "success", `Updated grade ID: ${id}`);
    fetchGrades();
  };

  const deleteGrade = async (id: number) => {
    const { error } = await supabase.from("grades").delete().eq("id", id);
    if (error) {
      toast.error("Failed to delete grade");
      throw error;
    }
    toast.success("Grade deleted");
    await logEvent("DELETE", undefined, "grades", window.location.pathname, "success", `Deleted grade ID: ${id}`);
    fetchGrades();
    fetchSections();
  };

  const createSection = async (grade_id: number, name: string) => {
    const { error } = await supabase
      .from("sections")
      .insert({ grade_id, name });
    if (error) {
      toast.error("Failed to create section");
      throw error;
    }
    toast.success("Section added");
    await logEvent("INSERT", undefined, "sections", window.location.pathname, "success", `Created section: ${name}`);
    fetchSections();
  };

  const updateSection = async (id: number, name: string) => {
    const { error } = await supabase
      .from("sections")
      .update({ name })
      .eq("id", id);
    if (error) {
      toast.error("Failed to update section");
      throw error;
    }
    toast.success("Section updated");
    await logEvent("UPDATE", undefined, "sections", window.location.pathname, "success", `Updated section ID: ${id}`);
    fetchSections();
  };

  const deleteSection = async (id: number) => {
    const { error } = await supabase.from("sections").delete().eq("id", id);
    if (error) {
      toast.error("Failed to delete section");
      throw error;
    }
    toast.success("Section deleted");
    await logEvent("DELETE", undefined, "sections", window.location.pathname, "success", `Deleted section ID: ${id}`);
    fetchSections();
  };

  return {
    grades,
    sections,
    isLoading,
    createGrade,
    updateGrade,
    deleteGrade,
    createSection,
    updateSection,
    deleteSection,
    fetchGrades,
    fetchSections,
  };
};
