"use client";

import { useRouter } from "next/navigation";
import { use, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase/client";
import { Loading } from "@/components/loading";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface SpellingScore {
  is_correct: boolean;
  attempted_at: string;
  spelling_words: {
    word: string;
  };
}

interface UserScore {
  game_mode: string;
  score: number;
  updated_at: string;
}

interface Props {
  params: { id: string };
}

export default function SpellingScoresPage({ params }: Props) {
  const router = useRouter();
  const { id: userId } = use(params);

  const [scores, setScores] = useState<SpellingScore[]>([]);
  const [userScores, setUserScores] = useState<UserScore[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;

    async function fetchScores() {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from("spelling_attempts")
        .select(
          `
          is_correct,
          attempted_at,
          spelling_words(word)
        `
        )
        .eq("user_id", userId)
        .order("attempted_at", { ascending: false });

      if (error) {
        console.error(error);
        setError("Failed to load attempts.");
        setLoading(false);
        return;
      }
      setScores(data ?? []);

      const { data: aggData, error: aggError } = await supabase
        .from("user_scores")
        .select("*")
        .eq("user_id", userId);

      if (aggError) {
        console.error(aggError);
        setError("Failed to load aggregated scores.");
      } else {
        setUserScores(aggData ?? []);
      }

      setLoading(false);
    }

    fetchScores();
  }, [userId]);

  if (loading) return <Loading />;

  return (
    <section className="space-y-8">
      <h1 className="text-3xl font-semibold">
        Spelling Game Scores & Progress
      </h1>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!error && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Aggregated Scores</CardTitle>
            </CardHeader>
            <CardContent>
              {userScores.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No aggregated scores found.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Game Mode</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Last Updated</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userScores.map(({ game_mode, score, updated_at }, i) => (
                      <TableRow key={i}>
                        <TableCell className="font-medium">
                          {game_mode}
                        </TableCell>
                        <TableCell>{score}</TableCell>
                        <TableCell>
                          {new Intl.DateTimeFormat(undefined, {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          }).format(new Date(updated_at))}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Detailed Attempts</CardTitle>
            </CardHeader>
            <CardContent>
              {scores.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No attempts found for this user.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Word</TableHead>
                      <TableHead>Correct</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {scores.map((score, index) => (
                      <TableRow
                        key={index}
                        className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                        <TableCell className="font-medium">
                          {score.spelling_words.word}
                        </TableCell>
                        <TableCell>{score.is_correct ? "Yes" : "No"}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          {new Intl.DateTimeFormat(undefined, {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          }).format(new Date(score.attempted_at))}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </>
      )}

      <Button variant="outline" onClick={() => router.back()}>
        Back
      </Button>
    </section>
  );
}
