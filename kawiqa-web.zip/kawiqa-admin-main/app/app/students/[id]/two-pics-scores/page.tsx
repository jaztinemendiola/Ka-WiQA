"use client";

import { useRouter } from "next/navigation";
import { use, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase/client";
import { Loading } from "@/components/loading";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface UserScore {
  game_mode: string;
  score: number;
  updated_at: string;
}

interface Progress {
  question_id: number;
  completed: boolean;
  completed_at: string;
  picture_word_guess_questions: {
    level: number;
    image_1: string;
    image_2: string;
    answer: string;
  };
}

interface Props {
  params: { id: string };
}

export default function GameOneScoresPage({ params }: Props) {
  const router = useRouter();
  const { id: userId } = use(params);

  const [userScores, setUserScores] = useState<UserScore[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;

    async function fetchData() {
      setLoading(true);
      setError(null);

      // Fetch aggregated scores for gameone mode
      const { data: scoresData, error: scoresError } = await supabase
        .from("user_scores")
        .select("*")
        .eq("user_id", userId)
        .eq("game_mode", "picture_guess");

      if (scoresError) {
        console.error(scoresError);
        setError("Failed to load game scores.");
      } else {
        setUserScores(scoresData ?? []);
      }

      // Fetch progress with question details
      const { data: progressData, error: progressError } = await supabase
        .from("picture_word_guess_question_progress")
        .select(
          `
          question_id,
          completed,
          picture_word_guess_questions(level, image_1, image_2, answer)
        `,
        )
        .eq("user_id", userId)
        .order("created_at", { ascending: false });

      if (progressError) {
        console.error(progressError);
        setError("Failed to load progress data.");
      } else {
        setProgress(progressData ?? []);
      }

      setLoading(false);
    }

    fetchData();
  }, [userId]);

  if (loading) return <Loading />;

  return (
    <section className="space-y-8">
      <h1 className="text-3xl font-semibold">GameOne Scores & Progress</h1>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!error && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Aggregated Scores</CardTitle>
            </CardHeader>
            <CardContent>
              {userScores.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No aggregated scores found for GameOne.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Score</TableHead>
                      <TableHead>Last Updated</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userScores.map(({ score, updated_at }, i) => (
                      <TableRow key={i}>
                        <TableCell>{score}</TableCell>
                        <TableCell>
                          {new Intl.DateTimeFormat(undefined, {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          }).format(new Date(updated_at))}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>User Progress</CardTitle>
            </CardHeader>
            <CardContent>
              {progress.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No progress found for this user.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Level</TableHead>
                      <TableHead>Images</TableHead>
                      <TableHead>Answer</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {progress.map(
                      (
                        {
                          question_id,
                          completed,
                          picture_word_guess_questions: gameone_questions,
                        },
                        index,
                      ) => (
                        <TableRow
                          key={question_id}
                          className={
                            index % 2 === 0 ? "bg-white" : "bg-gray-50"
                          }>
                          <TableCell className="font-medium">
                            {gameone_questions.level}
                          </TableCell>
                          <TableCell className="flex gap-2">
                            <img
                              src={gameone_questions.image_1}
                              alt={`Level ${gameone_questions.level} image 1`}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <img
                              src={gameone_questions.image_2}
                              alt={`Level ${gameone_questions.level} image 2`}
                              className="w-16 h-16 object-cover rounded"
                            />
                          </TableCell>
                          <TableCell>{gameone_questions.answer}</TableCell>
                          <TableCell>
                            {completed ? (
                              <span className="text-green-600 font-semibold">
                                Completed
                              </span>
                            ) : (
                              <span className="text-yellow-600 font-semibold">
                                Incomplete
                              </span>
                            )}
                          </TableCell>
                        </TableRow>
                      ),
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </>
      )}

      <Button variant="outline" onClick={() => router.back()}>
        Back
      </Button>
    </section>
  );
}
