"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase/client";
import { useToggle } from "@uidotdev/usehooks";
import { toast } from "sonner";
import { Database } from "@/types/database.types";
import useAuditLogs from "@/hooks/useAuditLogs";

export type Vocabulary = Database["public"]["Tables"]["vocabularies"]["Row"] & {
  grades?: {
    id: number;
    name: string;
  } | null;
  sections?: {
    id: number;
    name: string;
  } | null;
};
export type VocabularyInsert =
  Database["public"]["Tables"]["vocabularies"]["Insert"];

const useVocabulary = () => {
  const [isLoading, setLoading] = useToggle();
  const [vocabularies, setVocabularies] = useState<Vocabulary[]>([]);
  const { logEvent } = useAuditLogs();

  const fetchVocabularies = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("vocabularies")
      .select(
        `*,
        grades!vocabularies_grade_id_fkey(name),
        sections!vocabularies_section_id_fkey(name)`,
      )
      .order("created_at", { ascending: false });
    setLoading(false);

    if (error) {
      toast.error("Something went wrong!");
      throw error;
    }

    setVocabularies(data || []);
    return data;
  };

  const addVocabulary = async (vocab: Vocabulary) => {
    setLoading(true);
    const { data, error } = await supabase.from("vocabularies").insert([vocab]);
    setLoading(false);
    if (error) {
      toast.error("Something went wrong!");
      throw error;
    }
    toast.success("Success");
    await logEvent("INSERT", undefined, "vocabularies", window.location.pathname, "success", `Added vocabulary: ${vocab.word}`);
  };

  const updateVocabulary = async (id: number, vocab: Vocabulary) => {
    setLoading(true);
    const { error } = await supabase
      .from("vocabularies")
      .update(vocab)
      .eq("id", id);
    setLoading(false);
    if (error) {
      toast.error("Something went wrong!");
      throw error;
    }
    toast.success("Success");
    await logEvent("UPDATE", undefined, "vocabularies", window.location.pathname, "success", `Updated vocabulary ID: ${id}`);
  };

  const deleteVocabulary = async (id: number) => {
    setLoading(true);
    const { error } = await supabase.from("vocabularies").delete().eq("id", id);
    setLoading(false);
    if (error) {
      toast.error("Something went wrong!");
      throw error;
    }
    toast.success("Success");
    await logEvent("DELETE", undefined, "vocabularies", window.location.pathname, "success", `Deleted vocabulary ID: ${id}`);
  };

  return {
    isLoading,
    vocabularies,
    fetchVocabularies,
    addVocabulary,
    updateVocabulary,
    deleteVocabulary,
  };
};

export default useVocabulary;
