"use client";

import React, { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase/client";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loading } from "@/components/loading";
import useVocabulary, {
  Vocabulary,
  VocabularyInsert,
} from "./hooks/useVocablaries";
import { VocabularyDialog } from "./components/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import useCategories from "@/hooks/useCategories";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

export default function VocabularyPage() {
  const {
    isLoading,
    vocabularies,
    fetchVocabularies,
    addVocabulary,
    updateVocabulary,
    deleteVocabulary,
  } = useVocabulary();
  const { categories } = useCategories();

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Vocabulary | null>(null);
  const [form, setForm] = useState<Partial<VocabularyInsert>>({
    category_id: 1,
  });
   const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [grade, setGrade] = useState<string>("all");
  const [section, setSection] = useState<string>("all");
  const [grades, setGrades] = useState<{ id: number; name: string }[]>([]);
  const [sections, setSections] = useState<{ id: number; name: string }[]>([]);
  const [formErrors, setFormErrors] = useState<{
    category_id?: string;
    word?: string;
    word_en?: string;
    example_word?: string;
    letter_upper?: string;
    letter_lower?: string;
    number?: string;
  }>({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchVocabularies();
    fetchGrades();
    fetchSections();
  }, []);

  const fetchGrades = async () => {
    const { data } = await supabase
      .from("grades")
      .select("id, name")
      .order("name");
    if (data) setGrades(data);
  };

  const fetchSections = async () => {
    const { data } = await supabase
      .from("sections")
      .select("id, name")
      .order("name");
    if (data) setSections(data);
  };

  const handleChange = (
    key: keyof Vocabulary,
    value: string | number | null,
  ) => {
    setForm(prev => ({ ...prev, [key]: value }));
    // Clear error for this field
    const errorKey = key as keyof typeof formErrors;
    if (formErrors[errorKey]) {
      setFormErrors(prev => ({ ...prev, [errorKey]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const errors: typeof formErrors = {};
    const selectedCategory = categories.find(c => c.id === form.category_id);
    
    // Category is required
    if (!form.category_id) {
      errors.category_id = "Category is required";
    }
    
    // Word (Filipino) is required for all types
    if (!form.word?.trim()) {
      errors.word = "Word (Filipino) is required";
    }
    
    // Word (English) is required for all types
    if (!form.word_en?.trim()) {
      errors.word_en = "Word (English) is required";
    }
    
    // Example/Pronunciation required for all types
    if (!form.example_word?.trim()) {
      errors.example_word = "Example/Pronunciation is required";
    }
    
    // Category-specific validation
    if (selectedCategory) {
      switch (selectedCategory.name) {
        case "Alpabeto":
          if (!form.letter_upper?.trim()) {
            errors.letter_upper = "Letter (Uppercase) is required";
          }
          if (!form.letter_lower?.trim()) {
            errors.letter_lower = "Letter (Lowercase) is required";
          }
          break;
        case "Mga Numero":
          if (form.number === undefined || form.number === null) {
            errors.number = "Number is required";
          }
          break;
        // Other categories (Colors, Animals, Fruits, etc.) only need the generic fields
      }
    } else {
      errors.category_id = "Please select a category";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    setIsSaving(true);
    setFormErrors({});
    
    try {
      const payload = {
        category_id: form.category_id,
        word: form.word!.trim(),
        word_en: form.word_en!.trim(),
        example_word: form.example_word?.trim() || null,
        phonetic: form.phonetic || null,
        tips: form.tips || null,
        picture: form.picture || null,
        grade_id: form.grade_id || null,
        section_id: form.section_id || null,
        color: form.color || null,
        letter_upper: form.letter_upper?.trim() || null,
        letter_lower: form.letter_lower?.trim() || null,
        number: form.number || null,
      };

      if (editing?.id) {
        await updateVocabulary(editing.id, payload as Vocabulary);
      } else {
        await addVocabulary(payload as Vocabulary);
      }

      await fetchVocabularies();
      setOpen(false);
    } catch (e: unknown) {
      console.error("Error saving vocabulary:", e);
      // Hook already displays error toast
    } finally {
      setIsSaving(false);
    }
  };

  const handleEdit = (v: VocabularyInsert) => {
    const found = vocabularies.find(voca => voca?.id === v?.id);
    if (!found) return;

    const { grades, sections, ...voca } = found;

    setEditing(voca);
    setForm({ ...voca });
    setFormErrors({});
    setOpen(true);
  };

  const handleDelete = async (id?: number) => {
    if (!id) return;
    await deleteVocabulary(id);
    await fetchVocabularies();
  };

  const filtered = useMemo(() => {
    if (!vocabularies) return [];

    let results = vocabularies;

    // Filter by category if selected
    if (category && category !== "all") {
      results = results.filter(v => v.category_id === Number(category));
    }

    // Filter by grade if selected
    if (grade !== "all") {
      results = results.filter(
        v => v.grade_id === (grade === "none" ? null : Number(grade)),
      );
    }

    // Filter by section if selected
    if (section !== "all") {
      results = results.filter(
        v => v.section_id === (section === "none" ? null : Number(section)),
      );
    }

    // Filter by search if not empty
    if (search.trim()) {
      const s = search.toLowerCase();
      results = results.filter(
        v =>
          v.word.toLowerCase().includes(s) ||
          (v.word_en && v.word_en.toLowerCase().includes(s)) ||
          (v.example_word && v.example_word.toLowerCase().includes(s)) ||
          (v.grades && v.grades?.name.toLowerCase().includes(s)) ||
          (v.sections && v.sections?.name.toLowerCase().includes(s)) ||
          (v.color && v.color.toLowerCase().includes(s)),
      );
    }

    return results;
  }, [search, vocabularies, category, grade, section]);

  return (
    <div className="flex flex-col h-full min-h-0 overflow-x-auto">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Vocabularies</h1>
          <p className="text-sm text-muted-foreground">
            Manage vocabulary words by category
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-1/2">
          <Input
            placeholder="Search word..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className=""
          />
           <Button
             onClick={() => {
               setEditing(null);
               setForm({ category_id: 1 });
               setFormErrors({});
               setOpen(true);
             }}>
             Add
           </Button>
        </div>
      </div>

      {isLoading && <Loading />}

      <div className="grid sm:grid-cols-8 gap-2 mb-4">
        <Select
          value={String(category)}
          onValueChange={val => setCategory(val)}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(cat => (
              <SelectItem key={cat.id} value={String(cat.id)}>
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={grade} onValueChange={setGrade}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Grades" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Grades</SelectItem>
            <SelectItem value="none">None</SelectItem>
            {grades.map(g => (
              <SelectItem key={g.id} value={g.id.toString()}>
                {g.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* <Select value={section} onValueChange={setSection}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Sections" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sections</SelectItem>
            <SelectItem value="none">None</SelectItem>
            {sections.map(s => (
              <SelectItem key={s.id} value={s.id.toString()}>
                {s.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select> */}
      </div>

      <Card className="flex-1 flex flex-col overflow-hidden">
        <CardHeader>
          <CardTitle>Word List</CardTitle>
          <CardDescription>All vocabulary entries</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 overflow-auto">
          <Table className="w-full min-w-[600px]">
            <TableHeader>
              <TableRow>
                <TableHead>Word</TableHead>
                <TableHead>English</TableHead>
                <TableHead>Example</TableHead>
                <TableHead>Grade</TableHead>
                {/* <TableHead>Section</TableHead> */}
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(v => (
                <TableRow key={v.id}>
                  <TableCell>{v.word}</TableCell>
                  <TableCell>{v.word_en}</TableCell>
                  <TableCell>{v.example_word}</TableCell>
                  <TableCell>{v.grades?.name}</TableCell>
                  {/* <TableCell>{v.sections?.name}</TableCell> */}
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(v)}>
                        Edit
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive">Delete</Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <div className="flex items-center gap-2">
                              <Trash2 className="size-5 text-destructive" />
                              <AlertDialogTitle>Delete</AlertDialogTitle>
                            </div>
                            <AlertDialogDescription>
                              This will permanently delete. This action cannot
                              be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-white hover:bg-destructive/90"
                              onClick={() => handleDelete(v.id)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="text-center text-muted-foreground">
                    No vocabulary found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <VocabularyDialog
        open={open}
        onOpenChange={setOpen}
        form={form}
        onChange={handleChange}
        onSave={handleSave}
        isSaving={isSaving}
        formErrors={formErrors}
      />
    </div>
  );
}
