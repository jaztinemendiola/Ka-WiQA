"use client";

import React, { use, useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import Image from "next/image";
import { supabase } from "@/lib/supabase/client";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import useCategories from "@/hooks/useCategories";
import { Vocabulary } from "../hooks/useVocablaries";
import { toast } from "sonner";
import useSchoolData from "@/hooks/useSchoolData";

interface VocabularyDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  form: Partial<Vocabulary>;
  onChange: (key: keyof Vocabulary, value: any) => void;
  onSave: () => void;
  isSaving: boolean;
  formErrors?: {
    category_id?: string;
    word?: string;
    word_en?: string;
    example_word?: string;
    letter_upper?: string;
    letter_lower?: string;
    number?: string;
  };
}

export const VocabularyDialog: React.FC<VocabularyDialogProps> = ({
  open,
  onOpenChange,
  form,
  onChange,
  onSave,
  isSaving,
  formErrors,
}) => {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const { categories } = useCategories();
  const { refetch, grades, getSectionsByGrade } = useSchoolData();

  useEffect(() => {
    refetch();
  }, []);

  useEffect(() => {
    if (!form?.picture) return;
    setPreview(form?.picture);
  }, [form?.picture]);

  const selectedCategory = useMemo(
    () => categories.find(c => c.id === form.category_id),
    [categories, form.category_id],
  );

  const handleImageUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    try {
      const file = event.target.files?.[0];
      if (!file) return;

      setUploading(true);
      const categoryName =
        categories
          ?.find(category => category?.id === form?.category_id)
          ?.name?.toLowerCase() ?? "unknown-category";
      const fileExt = file.name.split(".").pop();
      const fileName = file?.name ?? new Date() + (fileExt ?? ".png");
      const filePath = `${categoryName}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from("vocabularies")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from("vocabularies")
        .getPublicUrl(filePath);
      if (data?.publicUrl) {
        toast.success("Successfully uploaded!");
        setPreview(data.publicUrl);
        onChange("picture", data.publicUrl);
      }
    } catch (error: any) {
      console.error("Image upload failed:", error.message);
      toast.error("Something went wrong!");
    } finally {
      setUploading(false);
    }
  };

  // Determines which fields to show based on category name
  const renderCategoryFields = () => {
    if (!selectedCategory) return null;

    switch (selectedCategory.name) {
      case "Alpabeto":
        return (
          <>
            <div className="space-y-2">
              <Label>
                Letter (Uppercase) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.letter_upper ?? ""}
                onChange={e => onChange("letter_upper", e.target.value)}
                placeholder="e.g., A"
                className={formErrors?.letter_upper ? "border-destructive" : ""}
              />
              {formErrors?.letter_upper && (
                <p className="text-sm text-destructive">{formErrors.letter_upper}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label>
                Letter (Lowercase) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.letter_lower ?? ""}
                onChange={e => onChange("letter_lower", e.target.value)}
                placeholder="e.g., a"
                className={formErrors?.letter_lower ? "border-destructive" : ""}
              />
              {formErrors?.letter_lower && (
                <p className="text-sm text-destructive">{formErrors.letter_lower}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label>
                Word (Filipino) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.word ?? ""}
                onChange={e => onChange("word", e.target.value)}
                placeholder="e.g., Saging"
                className={formErrors?.word ? "border-destructive" : ""}
              />
              {formErrors?.word && (
                <p className="text-sm text-destructive">{formErrors.word}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Word (English) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.word_en ?? ""}
                onChange={e => onChange("word_en", e.target.value)}
                placeholder="e.g., Banana"
                className={formErrors?.word_en ? "border-destructive" : ""}
              />
              {formErrors?.word_en && (
                <p className="text-sm text-destructive">{formErrors.word_en}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Example / Pronunciation <span className="text-destructive">*</span>
              </Label>
              <Textarea
                value={form.example_word ?? ""}
                onChange={e => onChange("example_word", e.target.value)}
                placeholder="e.g., Sa-ging // sáh-ging"
                className={formErrors?.example_word ? "border-destructive" : ""}
              />
              {formErrors?.example_word && (
                <p className="text-sm text-destructive">{formErrors.example_word}</p>
              )}
            </div>
          </>
        );

      case "Mga Numero":
        return (
          <div className="space-y-2">
            <Label>
              Number <span className="text-destructive">*</span>
            </Label>
            <Input
              type="number"
              value={form.number ?? ""}
              onChange={e => onChange("number", Number(e.target.value))}
              placeholder="e.g., 1"
              className={formErrors?.number ? "border-destructive" : ""}
            />
            {formErrors?.number && (
              <p className="text-sm text-destructive">{formErrors.number}</p>
            )}
            <div className="space-y-2">
              <Label>
                Word (Filipino) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.word ?? ""}
                onChange={e => onChange("word", e.target.value)}
                placeholder="e.g., Saging"
                className={formErrors?.word ? "border-destructive" : ""}
              />
              {formErrors?.word && (
                <p className="text-sm text-destructive">{formErrors.word}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Word (English) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.word_en ?? ""}
                onChange={e => onChange("word_en", e.target.value)}
                placeholder="e.g., Banana"
                className={formErrors?.word_en ? "border-destructive" : ""}
              />
              {formErrors?.word_en && (
                <p className="text-sm text-destructive">{formErrors.word_en}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Example / Pronunciation <span className="text-destructive">*</span>
              </Label>
              <Textarea
                value={form.example_word ?? ""}
                onChange={e => onChange("example_word", e.target.value)}
                placeholder="e.g., Sa-ging // sáh-ging"
                className={formErrors?.example_word ? "border-destructive" : ""}
              />
              {formErrors?.example_word && (
                <p className="text-sm text-destructive">{formErrors.example_word}</p>
              )}
            </div>
          </div>
        );

      default:
        // For colors, animals, fruits, greetings, unfamiliar words, etc.
        return (
          <>
            <div className="space-y-2">
              <Label>
                Word (Filipino) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.word ?? ""}
                onChange={e => onChange("word", e.target.value)}
                placeholder="e.g., Saging"
                className={formErrors?.word ? "border-destructive" : ""}
              />
              {formErrors?.word && (
                <p className="text-sm text-destructive">{formErrors.word}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Word (English) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form.word_en ?? ""}
                onChange={e => onChange("word_en", e.target.value)}
                placeholder="e.g., Banana"
                className={formErrors?.word_en ? "border-destructive" : ""}
              />
              {formErrors?.word_en && (
                <p className="text-sm text-destructive">{formErrors.word_en}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Example / Pronunciation <span className="text-destructive">*</span>
              </Label>
              <Textarea
                value={form.example_word ?? ""}
                onChange={e => onChange("example_word", e.target.value)}
                placeholder="e.g., Sa-ging // sáh-ging"
                className={formErrors?.example_word ? "border-destructive" : ""}
              />
              {formErrors?.example_word && (
                <p className="text-sm text-destructive">{formErrors.example_word}</p>
              )}
            </div>

            {selectedCategory.name === "Mga Kulay" && (
              <div className="space-y-2">
                <Label>Color Code</Label>
                <Input
                  value={form.color ?? ""}
                  onChange={e => onChange("color", e.target.value)}
                  placeholder="e.g., #FFAA00"
                />
              </div>
            )}
          </>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh]">
        <DialogHeader>
          <DialogTitle>
            {form.id ? "Edit Vocabulary" : "Add Vocabulary"}
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[65vh] pr-2">
          <div className="space-y-4 py-2">
            {/* CATEGORY SELECT */}
            <div className="space-y-2">
              <Label>
                Category <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.category_id ? String(form.category_id) : ""}
                onValueChange={val => onChange("category_id", Number(val))}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={String(cat.id)}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formErrors?.category_id && (
                <p className="text-sm text-destructive">{formErrors.category_id}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="grade_id">Grade</Label>
              <Select
                onValueChange={value => onChange("grade_id", Number(value))}
                value={form.grade_id ? String(form.grade_id) : ""}>
                <SelectTrigger id="grade_id" className="w-full">
                  <SelectValue placeholder="Select Grade" />
                </SelectTrigger>
                <SelectContent>
                  {grades.map(g => (
                    <SelectItem key={g.id} value={String(g.id)}>
                      {g.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* <div className="space-y-2">
              <Label htmlFor="section_id">Section</Label>
              <Select
                onValueChange={value => onChange("section_id", Number(value))}
                disabled={!form.grade_id}
                value={form.section_id ? String(form.section_id) : ""}>
                <SelectTrigger id="section_id" className="w-full">
                  <SelectValue placeholder="Select Grade" />
                </SelectTrigger>
                <SelectContent>
                  {form?.grade_id &&
                    getSectionsByGrade(form?.grade_id).map(s => (
                      <SelectItem key={s.id} value={String(s.id)}>
                        {s.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div> */}

            {renderCategoryFields()}

            <div className="space-y-2">
              <Label>Meaning</Label>
              <Textarea
                value={form.meaning ?? ""}
                onChange={e => onChange("meaning", e.target.value)}
                placeholder="e.g., meaning..."
              />
            </div>

            <div className="space-y-2">
              <Label>Picture</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                disabled={uploading}
              />
              {preview && (
                <Image
                  src={preview}
                  alt="Preview"
                  width={400}
                  height={200}
                  className="rounded-md border object-cover mt-2"
                />
              )}
            </div>
          </div>
        </ScrollArea>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isSaving}>
            Cancel
          </Button>
          <Button onClick={onSave} disabled={isSaving || uploading}>
            {isSaving ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
