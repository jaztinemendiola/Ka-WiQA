"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/lib/supabase/client";
import { Label } from "@/components/ui/label";
import Image from "next/image";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import useAuditLogs from "@/hooks/useAuditLogs";
import { useAuthStore } from "@/stores/auth";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Pronunciation {
  id?: number;
  word_ph: string;
  pagbigkas: string;
  tips?: string[];
  picture?: string;
  recorded_audio?: string;
  status?: "pending" | "approved" | "rejected";
}

const sanitizeFileName = (name: string) =>
  name
    .normalize("NFKD")
    .replace(/[^\w.\-]/g, "_")
    .replace(/_+/g, "_");
const PronunciationPage = () => {
  const [pronunciations, setPronunciations] = useState<Pronunciation[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Pronunciation | null>(null);
  const [form, setForm] = useState<Pronunciation>({
    word_ph: "",
    pagbigkas: "",
    tips: [],
    picture: "",
    recorded_audio: "",
    status: "pending",
  });
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [pictureFile, setPictureFile] = useState<File | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudioBlob, setRecordedAudioBlob] = useState<Blob | null>(null);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordingError, setRecordingError] = useState<string | null>(null);
   const [audioLevels, setAudioLevels] = useState<number[]>(Array(20).fill(0));
  const [formErrors, setFormErrors] = useState<{
    word_ph?: string;
    pagbigkas?: string;
    audio?: string;
  }>({});
  const [isSaving, setIsSaving] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const { isAdmin, user } = useAuthStore();
  const { logEvent } = useAuditLogs();

  useEffect(() => {
    fetchPronunciations();
  }, []);

  // Cleanup recorded audio URL on unmount
  useEffect(() => {
    return () => {
      if (recordedAudioUrl) {
        URL.revokeObjectURL(recordedAudioUrl);
      }
    };
  }, [recordedAudioUrl]);

  const toggleRecording = async () => {
    if (isRecording) {
      // Stop recording
      setRecordingError(null);
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== "inactive"
      ) {
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current.stream
          .getTracks()
          .forEach(track => track.stop());
      }
      if (
        audioContextRef.current &&
        audioContextRef.current.state !== "closed"
      ) {
        audioContextRef.current.close();
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      setIsRecording(false);
      return;
    }

     // Start recording
     try {
       setRecordingError(null);
       if (formErrors.audio) {
         setFormErrors(prev => ({ ...prev, audio: undefined }));
       }
       const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = e => {
        if (e.data.size > 0) {
          chunks.push(e.data);
        }
      };

       mediaRecorder.onstop = () => {
         const blob = new Blob(chunks, { type: "audio/webm" });
         setRecordedAudioBlob(blob);
         const url = URL.createObjectURL(blob);
         setRecordedAudioUrl(prev => {
           if (prev) URL.revokeObjectURL(prev);
           return url;
         });

         const file = new File([blob], `recording_${Date.now()}.webm`, {
           type: "audio/webm",
         });
         setAudioFile(file);
         
         // Clear audio error since we now have recording
         if (formErrors.audio) {
           setFormErrors(prev => ({ ...prev, audio: undefined }));
         }

         if (animationFrameRef.current) {
           cancelAnimationFrame(animationFrameRef.current);
         }
         if (
           audioContextRef.current &&
           audioContextRef.current.state !== "closed"
         ) {
           audioContextRef.current.close();
         }
         setAudioLevels(Array(20).fill(0));
       };

      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;

      // Set up audio visualization
      const audioContext = new AudioContext();
      audioContextRef.current = audioContext;
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 64;
      source.connect(analyser);
      analyserRef.current = analyser;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const updateLevels = () => {
        if (!isRecording) return;
        analyser.getByteFrequencyData(dataArray);
        const avgLevel =
          dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
        const normalized = Math.min(avgLevel / 128, 1);
        setAudioLevels(prev => [...prev.slice(1), normalized]);
        animationFrameRef.current = requestAnimationFrame(updateLevels);
      };
      updateLevels();

      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      setRecordingError("Microphone access denied or unavailable.");
    }
  };

  const fetchPronunciations = async () => {
    const { data, error } = await supabase
      .from("pronunciations")
      .select("*")
      .order("id", { ascending: true });
    if (error) {
      toast.error(
        <div>
          <div>Something went wrong!</div>
          <div>{error.message}</div>
        </div>,
      );
      throw error;
    }

    setPronunciations(data || []);
  };

  const validateForm = (): boolean => {
    const errors: { word_ph?: string; pagbigkas?: string; audio?: string } = {};
    
    // Validate Word (Filipino)
    if (!form.word_ph.trim()) {
      errors.word_ph = "Word (Filipino) is required";
    } else if (form.word_ph.trim().length < 2) {
      errors.word_ph = "Word must be at least 2 characters";
    }
    
    // Validate Pagbigkas (pronunciation)
    if (!form.pagbigkas.trim()) {
      errors.pagbigkas = "Pagbigkas is required";
    } else if (form.pagbigkas.trim().length < 2) {
      errors.pagbigkas = "Pagbigkas must be at least 2 characters";
    }
    
    // Validate audio - must have either recorded audio or uploaded file OR existing audio when editing
    const hasExistingAudio = editing && form.recorded_audio;
    const hasNewAudio = recordedAudioBlob || audioFile;
    if (!hasExistingAudio && !hasNewAudio) {
      errors.audio = "Either record audio or upload an audio file is required";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

   const handleSave = async () => {
     // Validate form first
     if (!validateForm()) {
       toast.error("Please fill in all required fields");
       return;
     }
     
     setIsSaving(true);
     setFormErrors({});
     
     try {
       let audioUrl = form.recorded_audio;
       let pictureUrl = form.picture;

       // Upload picture if provided
       if (pictureFile) {
         const picturePath = `${Date.now()}_${sanitizeFileName(pictureFile.name)}`;
         const { error: pictureError } = await supabase.storage
           .from("pronunciations")
           .upload(picturePath, pictureFile);
         
         if (pictureError) {
           console.error("Picture upload error:", pictureError.message);
           toast.error(
             <div>
               <div>Something went wrong!</div>
               <div>Picture Error: {pictureError.message}</div>
             </div>,
           );
           
           await logEvent(
             "INSERT",
             user?.id,
             "pronunciations",
             window.location.pathname,
             "error",
             "User saving picture attempt failed.",
           );
           
           throw pictureError;
         } else {
           const { data: publicUrlData } = supabase.storage
             .from("pronunciations")
             .getPublicUrl(picturePath);
           pictureUrl = publicUrlData.publicUrl;
         }
       }

       // Upload audio if provided
       // PRIORITY 1: Recorded audio
       if (recordedAudioBlob) {
         const audioPath = `${Date.now()}_${sanitizeFileName(
           form.word_ph || "recording",
         )}.webm`;

         const recordedFile = new File([recordedAudioBlob], audioPath, {
           type: "audio/webm",
         });

         const { error: uploadError } = await supabase.storage
           .from("pronunciation_sounds")
           .upload(audioPath, recordedFile, {
             upsert: true,
           });

         if (uploadError) {
           console.error("Recorded audio upload error:", uploadError.message);

           toast.error(
             <div>
               <div>Something went wrong!</div>
               <div>Audio Error: {uploadError.message}</div>
             </div>,
           );

           await logEvent(
             "INSERT",
             user?.id,
             "pronunciations",
             window.location.pathname,
             "error",
             "User saving recorded audio attempt failed.",
           );

           throw uploadError;
         }

         const { data: publicUrlData } = supabase.storage
           .from("pronunciation_sounds")
           .getPublicUrl(audioPath);

         audioUrl = publicUrlData.publicUrl;

         // PRIORITY 2: Uploaded audio file
       } else if (audioFile) {
         const audioPath = `${Date.now()}_${sanitizeFileName(audioFile.name)}`;

         const { error: uploadError } = await supabase.storage
           .from("pronunciation_sounds")
           .upload(audioPath, audioFile, {
             upsert: true,
           });

         if (uploadError) {
           console.error("Audio upload error:", uploadError.message);

           toast.error(
             <div>
               <div>Something went wrong!</div>
               <div>Audio Error: {uploadError.message}</div>
             </div>,
           );

           await logEvent(
             "INSERT",
             user?.id,
             "pronunciations",
             window.location.pathname,
             "error",
             "User saving audio file attempt failed.",
           );

           throw uploadError;
         }

         const { data: publicUrlData } = supabase.storage
           .from("pronunciation_sounds")
           .getPublicUrl(audioPath);

         audioUrl = publicUrlData.publicUrl;
       }

       const payload = {
         word_ph: form.word_ph.trim(),
         pagbigkas: form.pagbigkas.trim(),
         tips: form.tips?.filter(tip => tip.trim()) || [],
         picture: pictureUrl,
         recorded_audio: audioUrl,
         status: form.status,
       };

       if (editing) {
         const { error } = await supabase
           .from("pronunciations")
           .update(payload)
           .eq("id", editing.id);
         
         if (error) throw error;
         
         await logEvent(
           "UPDATE",
           user?.id,
           "pronunciations",
           window.location.pathname,
           "success",
           `Updated pronunciation: ${form.word_ph}`,
         );
       } else {
         payload.status = isAdmin ? "approved" : "pending";
         const { error } = await supabase.from("pronunciations").insert(payload);
         if (error) throw error;
         
         await logEvent(
           "INSERT",
           user?.id,
           "pronunciations",
           window.location.pathname,
           "success",
           `Added pronunciation: ${form.word_ph}`,
         );
       }

       setOpen(false);
       setEditing(null);
       setForm({
         word_ph: "",
         pagbigkas: "",
         tips: [],
         picture: "",
         recorded_audio: "",
         status: "pending",
       });
       setAudioFile(null);
       setPictureFile(null);
       if (recordedAudioUrl) {
         URL.revokeObjectURL(recordedAudioUrl);
         setRecordedAudioUrl(null);
         setRecordedAudioBlob(null);
       }
       toast.success(editing ? "Pronunciation updated successfully" : "Pronunciation added successfully");
       fetchPronunciations();
     } catch (e: unknown) {
       console.error("Error saving pronunciation:", e);
       toast.error((String(e) as string) ?? "Something went wrong!");
      } finally {
        setIsSaving(false);
      }
    };

   const handleWordChange = (value: string) => {
      setForm(prev => ({ ...prev, word_ph: value }));
      if (formErrors.word_ph) {
        setFormErrors(prev => ({ ...prev, word_ph: undefined }));
      }
    };

   const handlePagbigkasChange = (value: string) => {
      setForm(prev => ({ ...prev, pagbigkas: value }));
      if (formErrors.pagbigkas) {
        setFormErrors(prev => ({ ...prev, pagbigkas: undefined }));
      }
    };

   const handleAudioChange = () => {
      if (formErrors.audio) {
        setFormErrors(prev => ({ ...prev, audio: undefined }));
      }
    };

   const handleDelete = async (id: number) => {
    try {
      await supabase.from("pronunciations").delete().eq("id", id);
      await logEvent(
        "DELETE",
        user?.id,
        "pronunciations",
        window.location.pathname,
        "success",
        `Deleted pronunciation ID: ${id}`,
      );
      toast.success("Success");
      fetchPronunciations();
    } catch {
      await logEvent(
        "DELETE",
        user?.id,
        "pronunciations",
        window.location.pathname,
        "error",
        "User delete attempt failed.",
      );
    }
  };

  const handleEdit = (p: Pronunciation) => {
    setEditing(p);
    setForm(p);
    setOpen(true);
  };

   useEffect(() => {
     if (!open) {
       setEditing(null);
       setForm({
         word_ph: "",
         pagbigkas: "",
         tips: [],
         picture: "",
         recorded_audio: "",
       });
       setAudioFile(null);
       setPictureFile(null);
       setFormErrors({});
       if (recordedAudioUrl) {
         URL.revokeObjectURL(recordedAudioUrl);
         setRecordedAudioUrl(null);
         setRecordedAudioBlob(null);
       }
     }
   }, [open, recordedAudioUrl]);

  // Filter results based on search input
  const filtered = useMemo(() => {
    let result = pronunciations;

    // Filter by status
    if (statusFilter !== "all") {
      result = result.filter(p => p.status === statusFilter);
    }

    // Filter by search
    if (search.trim()) {
      const s = search.toLowerCase();
      result = result.filter(
        p =>
          p.word_ph.toLowerCase().includes(s) ||
          p.pagbigkas.toLowerCase().includes(s) ||
          (p.tips && p.tips.join(", ").toLowerCase().includes(s)),
      );
    }

    return result;
  }, [search, statusFilter, pronunciations]);

  return (
    <div className="w-full space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Pronunciations</h1>
          <p className="text-muted-foreground text-sm">
            Manage Filipino pronunciations with audio and picture uploads
          </p>
        </div>

        <div className="flex gap-2 w-1/2 items-center">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Search word or tip..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <Button onClick={() => setOpen(true)}>Add Pronunciation</Button>
        </div>
      </div>

      <table className="min-w-full border text-sm">
        <thead>
          <tr className="bg-gray-100">
            <th className="border p-2">Word</th>
            <th className="border p-2">Pagbigkas</th>
            <th className="border p-2">Tips</th>
            <th className="border p-2">Picture</th>
            <th className="border p-2">Status</th>
            <th className="border p-2">Audio</th>
            <th className="border p-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(p => (
            <tr key={p.id}>
              <td className="border p-2">{p.word_ph}</td>
              <td className="border p-2">{p.pagbigkas}</td>
              <td className="border p-2">{p.tips?.join(", ")}</td>
              <td className="border p-2 text-center">
                {p.picture && (
                  <Image
                    src={p.picture}
                    height={200}
                    width={100}
                    alt="Picture"
                    className="object-cover rounded mx-auto"
                  />
                )}
              </td>
              <td className="border p-2">{p.status}</td>
              <td className="border p-2 text-center">
                {p.recorded_audio && (
                  <audio
                    controls
                    src={p.recorded_audio}
                    className="w-36 mx-auto"
                  />
                )}
              </td>
              <td className="border p-2 flex gap-2 justify-center">
                <Button onClick={() => handleEdit(p)}>Edit</Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">Delete</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <div className="flex items-center gap-2">
                        <Trash2 className="size-5 text-destructive" />
                        <AlertDialogTitle>Delete</AlertDialogTitle>
                      </div>
                      <AlertDialogDescription>
                        This will permanently delete. This action cannot be
                        undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-white hover:bg-destructive/90"
                        onClick={() => handleDelete(p.id!)}>
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </td>
            </tr>
          ))}

          {filtered.length === 0 && (
            <tr>
              <td colSpan={6} className="text-center text-muted-foreground p-4">
                No results found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Dialog for Add/Edit */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit Pronunciation" : "Add Pronunciation"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="word_ph">
                Word (Filipino) <span className="text-destructive">*</span>
              </Label>
              <Input
                id="word_ph"
                placeholder="Word (Filipino)"
                value={form.word_ph}
                onChange={e => handleWordChange(e.target.value)}
                className={formErrors.word_ph ? "border-destructive" : ""}
              />
              {formErrors.word_ph && (
                <p className="text-sm text-destructive mt-1">{formErrors.word_ph}</p>
              )}
            </div>
            <div>
              <Label htmlFor="pagbigkas">
                Pagbigkas <span className="text-destructive">*</span>
              </Label>
              <Input
                id="pagbigkas"
                placeholder="Pagbigkas"
                value={form.pagbigkas}
                onChange={e => handlePagbigkasChange(e.target.value)}
                className={formErrors.pagbigkas ? "border-destructive" : ""}
              />
              {formErrors.pagbigkas && (
                <p className="text-sm text-destructive mt-1">{formErrors.pagbigkas}</p>
              )}
            </div>
            <Textarea
              placeholder="Tips (comma separated)"
              value={form.tips?.join(", ")}
              onChange={e =>
                setForm({
                  ...form,
                  tips: e.target.value.split(",").map(x => x.trim()),
                })
              }
            />
            {isAdmin && (
              <Select
                value={form.status}
                onValueChange={value => setForm({ ...form, status: value })}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>

                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            )}

            <div className="space-y-2">
              <Label>Picture</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={e => setPictureFile(e.target.files?.[0] || null)}
              />
            </div>

            <div className="space-y-2">
              <Label>
                Recorded Audio <span className="text-destructive">*</span>
              </Label>
              <div className="flex flex-col gap-2">
                {recordedAudioUrl && (
                  <audio controls src={recordedAudioUrl} className="w-full" />
                )}
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-3">
                    <Button
                      type="button"
                      variant={isRecording ? "destructive" : "default"}
                      onClick={toggleRecording}
                      className="flex items-center gap-2">
                      {isRecording ? (
                        <>
                          <span className="size-3 rounded-full bg-white animate-pulse" />
                          Stop Recording
                        </>
                      ) : (
                        "Record Audio"
                      )}
                    </Button>
                    {isRecording && (
                      <span className="text-sm text-destructive animate-pulse">
                        Recording...
                      </span>
                    )}
                  </div>

                  {/* {isRecording && (
                    <div className="flex items-end gap-0.5 h-8 px-2 py-1 bg-muted rounded-md">
                      {audioLevels.map((level, i) => (
                        <div
                          key={i}
                          className="bg-primary transition-all duration-75 w-1 rounded-sm"
                          style={{ height: `${Math.max(4, level * 100)}%` }}
                        />
                      ))}
                    </div>
                  )} */}

                  {recordedAudioUrl && !isRecording && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setRecordedAudioBlob(null);
                        setRecordedAudioUrl(prev => {
                          if (prev) URL.revokeObjectURL(prev);
                          return null;
                        });
                        setAudioFile(null);
                        handleAudioChange();
                      }}>
                      Clear Recording
                    </Button>
                  )}
                </div>
                {recordingError && (
                  <p className="text-sm text-destructive">{recordingError}</p>
                )}
                {formErrors.audio && (
                  <p className="text-sm text-destructive">{formErrors.audio}</p>
                )}
              </div>
            </div>

            {!Boolean(recordedAudioUrl) && (
              <div className="space-y-2">
                <Label>Or Upload Audio File</Label>
                <Input
                  type="file"
                  accept="audio/*"
                  onChange={e => {
                    const file = e.target.files?.[0] || null;
                    setAudioFile(file);
                    handleAudioChange();
                    // Clear recorded audio if uploading instead
                    if (file && recordedAudioUrl) {
                      setRecordedAudioBlob(null);
                      setRecordedAudioUrl(null);
                    }
                  }}
                />
              </div>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setOpen(false)} disabled={isSaving}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving ? "Saving..." : editing ? "Update" : "Save"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PronunciationPage;
