"use client";

import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loading } from "@/components/loading";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Category {
  id: number;
  name: string;
}

interface SpellingWord {
  id?: number;
  word: string;
  word_en: string;
  hints: string[];
  max_attempts: number;
  category_id: number;
  grade_id?: number | null;
  section_id?: number | null;
  picture?: string;
  sort: number;
}

export default function SpellingWordsPage() {
  const [spellingWords, setSpellingWords] = useState<SpellingWord[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [grades, setGrades] = useState<{ id: number; name: string }[]>([]);
  const [sections, setSections] = useState<{ id: number; name: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<SpellingWord | null>(null);
  const [form, setForm] = useState<Partial<SpellingWord>>({
    word: "",
    word_en: "",
    hints: [],
    max_attempts: 3,
    category_id: 0,
    grade_id: null,
    section_id: null,
    sort: 1,
    picture: "",
  });
  const [pictureFile, setPictureFile] = useState<File | null>(null);
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterGrade, setFilterGrade] = useState<string>("all");
  const [filterSection, setFilterSection] = useState<string>("all");

  // Load data on mount
  useEffect(() => {
    fetchCategories();
    fetchGrades();
    fetchSections();
    fetchSpellingWords();
  }, []);

  useEffect(() => {
    if (!spellingWords.length) return;

    setForm(prev => ({
      ...prev,
      sort: spellingWords?.[spellingWords.length - 1]?.sort + 1,
    }));
  }, [spellingWords]);

  const fetchCategories = async () => {
    const { data, error } = await supabase.from("categories").select("*");
    if (error) {
      toast.error("Failed to load categories");
    } else {
      setCategories(data || []);
    }
  };

  const fetchGrades = async () => {
    const { data } = await supabase
      .from("grades")
      .select("id, name")
      .order("name");
    if (data) setGrades(data);
  };

  const fetchSections = async () => {
    const { data } = await supabase
      .from("sections")
      .select("id, name")
      .order("name");
    if (data) setSections(data);
  };

  const fetchSpellingWords = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("spelling_words")
      .select("*, categories(name)")
      .order("sort", { ascending: true });
    if (error) {
      toast.error("Failed to load spelling words");
    } else {
      setSpellingWords(data || []);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!form.word || !form.word_en || !form.category_id) {
      toast.error("Please complete all required fields");
      return;
    }

    setLoading(true);
    try {
      let pictureUrl = form.picture;

      // Upload picture if selected
      if (pictureFile) {
        const filePath = `spelling_pictures/${Date.now()}-${pictureFile.name}`;
        const { error: uploadError } = await supabase.storage
          .from("spelling_pictures")
          .upload(filePath, pictureFile);
        if (uploadError) throw uploadError;

        const { data: publicUrlData } = supabase.storage
          .from("spelling_pictures")
          .getPublicUrl(filePath);
        pictureUrl = publicUrlData.publicUrl;
      }

      const payload = {
        word: form.word,
        word_en: form.word_en,
        hints: form.hints || [],
        max_attempts: form.max_attempts || 3,
        category_id: form.category_id,
        grade_id: form.grade_id ?? null,
        section_id: form.section_id ?? null,
        picture: pictureUrl,
        sort: form.sort || 1,
      };

      if (editing) {
        const { error } = await supabase
          .from("spelling_words")
          .update(payload)
          .eq("id", editing.id);
        if (error) throw error;
        toast.success("Spelling word updated successfully");
      } else {
        const { error } = await supabase.from("spelling_words").insert(payload);
        if (error) throw error;
        toast.success("Spelling word added successfully");
      }

      setOpen(false);
      setEditing(null);
      setForm({
        word: "",
        word_en: "",
        hints: [],
        max_attempts: 3,
        category_id: 0,
        grade_id: null,
        section_id: null,
        sort: 1,
        picture: "",
      });
      fetchSpellingWords();
    } catch (e: any) {
      console.error(e.message);
      toast.error("Something went wrong while saving");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (item: SpellingWord) => {
    setEditing(item);
    setForm({
      ...item,
      hints: Array.isArray(item.hints)
        ? item.hints
        : JSON.parse(item.hints as any),
    });
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this word?")) return;
    const { error } = await supabase
      .from("spelling_words")
      .delete()
      .eq("id", id);
    if (error) {
      toast.error("Failed to delete word");
    } else {
      toast.success("Deleted successfully");
      fetchSpellingWords();
    }
  };

  const filtered = useMemo(() => {
    let filteredWords = spellingWords;

    if (search.trim()) {
      filteredWords = filteredWords.filter(
        s =>
          s.word.toLowerCase().includes(search.toLowerCase()) ||
          s.word_en.toLowerCase().includes(search.toLowerCase()),
      );
    }

    if (filterCategory !== "all") {
      filteredWords = filteredWords.filter(
        s => s.category_id === Number(filterCategory),
      );
    }

    if (filterGrade !== "all") {
      filteredWords = filteredWords.filter(
        s =>
          s.grade_id === (filterGrade === "none" ? null : Number(filterGrade)),
      );
    }

    if (filterSection !== "all") {
      filteredWords = filteredWords.filter(
        s =>
          s.section_id ===
          (filterSection === "none" ? null : Number(filterSection)),
      );
    }

    return filteredWords;
  }, [search, spellingWords, filterCategory, filterGrade, filterSection]);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-3xl font-bold">Spelling Words</h1>
        <div className="flex gap-2">
          <Input
            placeholder="Search word..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-64"
          />
          <Button onClick={() => setOpen(true)}>Add Word</Button>
        </div>
      </div>

      {loading && <Loading />}

      <div className="grid sm:grid-cols-8 gap-2 mb-4">
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(c => (
              <SelectItem key={c.id} value={c.id.toString()}>
                {c.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterGrade} onValueChange={setFilterGrade}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Grades" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Grades</SelectItem>
            <SelectItem value="none">None</SelectItem>
            {grades.map(g => (
              <SelectItem key={g.id} value={g.id.toString()}>
                {g.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* <Select value={filterSection} onValueChange={setFilterSection}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Sections" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sections</SelectItem>
            <SelectItem value="none">None</SelectItem>
            {sections.map(s => (
              <SelectItem key={s.id} value={s.id.toString()}>
                {s.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select> */}
      </div>

      <table className="min-w-full border text-sm">
        <thead>
          <tr className="bg-gray-100">
            <th className="border p-2 text-left">Word</th>
            <th className="border p-2 text-left">English</th>
            <th className="border p-2 text-left">Category</th>
            <th className="border p-2 text-left">Grade</th>
            {/* <th className="border p-2 text-left">Section</th> */}
            <th className="border p-2 text-center">Max Attempts</th>
            <th className="border p-2 text-center">Sort</th>
            <th className="border p-2 text-center">Picture</th>
            <th className="border p-2 text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(item => (
            <tr key={item.id}>
              <td className="border p-2">{item.word}</td>
              <td className="border p-2">{item.word_en}</td>
              <td className="border p-2">
                {categories.find(cat => cat.id === item.category_id)?.name}
              </td>
              <td className="border p-2">
                {grades.find(g => g.id === item.grade_id)?.name}
              </td>
              {/* <td className="border p-2">
                {sections.find(s => s.id === item.section_id)?.name}
              </td> */}
              <td className="border p-2 text-center">{item.max_attempts}</td>
              <td className="border p-2 text-center">{item.sort}</td>
              <td className="border p-2 text-center">
                {item.picture && (
                  <img
                    src={item.picture}
                    alt="pic"
                    className="w-10 h-10 object-cover mx-auto rounded"
                  />
                )}
              </td>
              <td className="border p-2 text-center flex gap-2 justify-center">
                <Button size="sm" onClick={() => handleEdit(item)}>
                  Edit
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">Delete</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <div className="flex items-center gap-2">
                        <Trash2 className="size-5 text-destructive" />
                        <AlertDialogTitle>Delete</AlertDialogTitle>
                      </div>
                      <AlertDialogDescription>
                        This will permanently delete. This action cannot be
                        undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-white hover:bg-destructive/90"
                        onClick={() => handleDelete(item.id!)}>
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </td>
            </tr>
          ))}
          {filtered.length === 0 && !loading && (
            <tr>
              <td colSpan={9} className="text-center p-4 text-muted-foreground">
                No spelling words found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Add / Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit Spelling Word" : "Add Spelling Word"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Word"
              value={form.word || ""}
              onChange={e => setForm({ ...form, word: e.target.value })}
            />
            <Input
              placeholder="English Word"
              value={form.word_en || ""}
              onChange={e => setForm({ ...form, word_en: e.target.value })}
            />
            <Textarea
              placeholder="Hints (comma separated)"
              value={form.hints?.join(", ") || ""}
              onChange={e =>
                setForm({
                  ...form,
                  hints: e.target.value.split(",").map(h => h.trim()),
                })
              }
            />
            <div>
              <Label>Category</Label>
              <Select
                value={String(form.category_id || "")}
                onValueChange={val =>
                  setForm({ ...form, category_id: Number(val) })
                }>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(c => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Grade</Label>
                <Select
                  value={form.grade_id?.toString() || "none"}
                  onValueChange={v =>
                    setForm({
                      ...form,
                      grade_id: v === "none" ? null : Number(v),
                    })
                  }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select grade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {grades.map(g => (
                      <SelectItem key={g.id} value={g.id.toString()}>
                        {g.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {/* <div>
                <Label>Section</Label>
                <Select
                  value={form.section_id?.toString() || "none"}
                  onValueChange={v =>
                    setForm({
                      ...form,
                      section_id: v === "none" ? null : Number(v),
                    })
                  }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select section" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {sections.map(s => (
                      <SelectItem key={s.id} value={s.id.toString()}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div> */}
            </div>
            <div>
              <Label>Max Attempts</Label>
              <Input
                type="number"
                value={form.max_attempts || 3}
                onChange={e =>
                  setForm({ ...form, max_attempts: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <Label>Sort Order</Label>
              <Input
                type="number"
                value={form.sort || 1}
                onChange={e =>
                  setForm({ ...form, sort: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <Label>Picture</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={e => setPictureFile(e.target.files?.[0] || null)}
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={loading}>
                {editing ? "Update" : "Save"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
