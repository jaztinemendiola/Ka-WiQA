"use client";

import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Loading } from "@/components/loading";
import Image from "next/image";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import useAuditLogs from "@/hooks/useAuditLogs";
import type { Json } from "@/types/database.types";
import { ScrollArea } from "@/components/ui/scroll-area";

interface RandomLetter {
  id: number;
  letter: string;
}

interface GameOneQuestion {
  id?: number;
  level: number;
  image_1: string;
  image_2: string;
  answer: string;
  random_letters: RandomLetter[];
  hints?: string[] | null;
  category_id?: number | null;
  grade_id?: number | null;
  section_id?: number | null;
  can_remove_letter?: boolean;
  can_reveal_first_word?: boolean;
  can_reveal_letter?: boolean;
  remove_letter_limit?: number | null;
  reveal_letter_limit?: number | null;
  created_at?: string | null;
}

export default function GameOneQuestionsPage() {
  const [questions, setQuestions] = useState<GameOneQuestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<GameOneQuestion | null>(null);
  const [form, setForm] = useState<Partial<GameOneQuestion>>({
    level: 1,
    answer: "",
    random_letters: [],
    hints: [],
    can_remove_letter: true,
    can_reveal_letter: true,
    remove_letter_limit: 1,
    reveal_letter_limit: 1,
  });
  const [image1, setImage1] = useState<File | null>(null);
  const [image2, setImage2] = useState<File | null>(null);
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterGrade, setFilterGrade] = useState<string>("all");
  const [filterSection, setFilterSection] = useState<string>("all");
  const [categories, setCategories] = useState<{ id: number; name: string }[]>(
    [],
  );
  const [grades, setGrades] = useState<{ id: number; name: string }[]>([]);
  const [sections, setSections] = useState<{ id: number; name: string }[]>([]);
  const { logEvent } = useAuditLogs();

  useEffect(() => {
    fetchQuestions();
    fetchCategories();
    fetchGrades();
    fetchSections();
  }, []);

  const fetchCategories = async () => {
    const { data } = await supabase
      .from("categories")
      .select("id, name")
      .order("name");
    if (data) setCategories(data);
  };

  const fetchGrades = async () => {
    const { data } = await supabase
      .from("grades")
      .select("id, name")
      .order("name");
    if (data) setGrades(data);
  };

  const fetchSections = async () => {
    const { data } = await supabase
      .from("sections")
      .select("id, name")
      .order("name");
    if (data) setSections(data);
  };

  const getNextLevel = async (
    categoryId: number | null,
    gradeId: number | null,
  ) => {
    let query = supabase
      .from("picture_word_guess_questions")
      .select("level")
      .order("level", { ascending: false })
      .limit(1);

    if (categoryId) {
      query = query.eq("category_id", categoryId);
    }
    if (gradeId) {
      query = query.eq("grade_id", gradeId);
    }

    const { data } = await query;
    if (data && data.length > 0) {
      return data[0].level + 1;
    }
    return 1;
  };

  const fetchQuestions = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("picture_word_guess_questions")
      .select("*")
      .order("level", { ascending: false });
    if (error) {
      toast.error("Failed to load questions");
    } else {
      setQuestions(data || []);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!form.level || !form.answer) {
      toast.error("Level and answer are required");
      return;
    }

    if (!image1 && !editing?.image_1) {
      toast.error("Image 1 is required");
      return;
    }
    if (!image2 && !editing?.image_2) {
      toast.error("Image 2 is required");
      return;
    }

    setLoading(true);
    try {
      let imageUrl1 = form.image_1;
      let imageUrl2 = form.image_2;

      // Upload new images if any
      if (image1) {
        const path1 = `gameone_pictures/${Date.now()}-${image1.name}`;
        const { error: uploadErr1 } = await supabase.storage
          .from("gameone_pictures")
          .upload(path1, image1);
        if (uploadErr1) throw uploadErr1;

        const { data } = supabase.storage
          .from("gameone_pictures")
          .getPublicUrl(path1);
        imageUrl1 = data.publicUrl;
      }

      if (image2) {
        const path2 = `gameone_pictures/${Date.now()}-${image2.name}`;
        const { error: uploadErr2 } = await supabase.storage
          .from("gameone_pictures")
          .upload(path2, image2);
        if (uploadErr2) throw uploadErr2;

        const { data } = supabase.storage
          .from("gameone_pictures")
          .getPublicUrl(path2);
        imageUrl2 = data.publicUrl;
      }

      const generateRandomLetters = (
        answer: string,
        totalCount: number = 12,
      ) => {
        const answerLetters = answer
          .toUpperCase()
          .replace(/[^A-Z]/g, "")
          .split("");
        const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
        const additionalLetters: string[] = [];

        for (let i = 0; i < totalCount - answerLetters.length; i++) {
          const randomLetter =
            alphabet[Math.floor(Math.random() * alphabet.length)];
          if (
            !answerLetters.includes(randomLetter) &&
            !additionalLetters.includes(randomLetter)
          ) {
            additionalLetters.push(randomLetter);
          } else {
            i--;
          }
        }

        const allLetters = [...answerLetters, ...additionalLetters];
        for (let i = allLetters.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [allLetters[i], allLetters[j]] = [allLetters[j], allLetters[i]];
        }

        return allLetters.map((letter, idx) => ({ id: idx, letter }));
      };

      const randomLetters = generateRandomLetters(form.answer || "", 12);

      const payload = {
        level: form.level,
        answer: form.answer.trim(),
        image_1: imageUrl1,
        image_2: imageUrl2,
        random_letters: randomLetters,
        hints: form.hints || [],
        category_id: form.category_id || null,
        grade_id: form.grade_id || null,
        section_id: form.section_id || null,
        can_remove_letter: form.can_remove_letter ?? false,
        can_reveal_first_word: form.can_reveal_first_word ?? false,
        can_reveal_letter: form.can_reveal_letter ?? false,
        remove_letter_limit: form.remove_letter_limit ?? null,
        reveal_letter_limit: form.reveal_letter_limit ?? null,
      };

      console.log(payload);

      if (editing) {
        const { error } = await supabase
          .from("picture_word_guess_questions")
          .update(payload)
          .eq("id", editing.id);
        if (error) throw error;
        await logEvent("UPDATE", undefined, "picture_word_guess_questions", window.location.pathname, "success", `Updated question ID: ${editing.id}`);
        toast.success("Question updated successfully");
      } else {
        const { error } = await supabase
          .from("picture_word_guess_questions")
          .insert(payload);
        if (error) throw error;
        await logEvent("INSERT", undefined, "picture_word_guess_questions", window.location.pathname, "success", `Added question: ${form.answer}`);
        toast.success("Question added successfully");
      }

      resetForm();
      fetchQuestions();
    } catch (err: any) {
      console.error(err.message);
      toast.error("Error while saving question");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (q: GameOneQuestion) => {
    setEditing(q);
    setForm({
      ...q,
      hints: Array.isArray(q.hints)
        ? q.hints
        : q.hints
          ? JSON.parse(q.hints as any)
          : [],
    });
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this question?")) return;
    const { error } = await supabase
      .from("picture_word_guess_questions")
      .delete()
      .eq("id", id);
    if (error) {
      toast.error("Failed to delete");
    } else {
      await logEvent("DELETE", undefined, "picture_word_guess_questions", window.location.pathname, "success", `Deleted question ID: ${id}`);
      toast.success("Deleted successfully");
      fetchQuestions();
    }
  };

  const resetForm = () => {
    setOpen(false);
    setEditing(null);
    setForm({
      level: 1,
      answer: "",
      random_letters: [],
      hints: [],
      can_remove_letter: false,
      can_reveal_letter: false,
      can_reveal_first_word: false,
      remove_letter_limit: null,
      reveal_letter_limit: null,
    });
    setImage1(null);
    setImage2(null);
  };

  const filtered = useMemo(() => {
    let filteredQuestions = questions;

    if (search.trim()) {
      filteredQuestions = filteredQuestions.filter(q =>
        q.answer.toLowerCase().includes(search.toLowerCase()),
      );
    }

    if (filterCategory !== "all") {
      filteredQuestions = filteredQuestions.filter(
        q =>
          q.category_id ===
          (filterCategory === "none" ? null : Number(filterCategory)),
      );
    }

    if (filterGrade !== "all") {
      filteredQuestions = filteredQuestions.filter(
        q =>
          q.grade_id === (filterGrade === "none" ? null : Number(filterGrade)),
      );
    }

    if (filterSection !== "all") {
      filteredQuestions = filteredQuestions.filter(
        q =>
          q.section_id ===
          (filterSection === "none" ? null : Number(filterSection)),
      );
    }

    return filteredQuestions;
  }, [search, questions, filterCategory, filterGrade, filterSection]);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-3xl font-bold">Game One Questions</h1>
        <div className="flex gap-2">
          <Input
            placeholder="Search by answer..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-64"
          />
          <Button
            onClick={async () => {
              const nextLevel = await getNextLevel(null, null);
              setOpen(true);
              setImage1(null);
              setImage2(null);
              setEditing(null);
              setForm({
                level: nextLevel,
                answer: "",
                random_letters: [],
                hints: [],
                category_id: null,
                grade_id: null,
                section_id: null,
                can_remove_letter: true,
                can_reveal_letter: true,
                can_reveal_first_word: false,
                remove_letter_limit: 1,
                reveal_letter_limit: 1,
              });
            }}>
            Add Question
          </Button>
        </div>
      </div>

      {loading && <Loading />}

      <div className="grid sm:grid-cols-8 gap-2 mb-4">
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="none">None</SelectItem>
            {categories.map(c => (
              <SelectItem key={c.id} value={c.id.toString()}>
                {c.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterGrade} onValueChange={setFilterGrade}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Grades" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Grades</SelectItem>
            <SelectItem value="none">None</SelectItem>
            {grades.map(g => (
              <SelectItem key={g.id} value={g.id.toString()}>
                {g.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* <Select value={filterSection} onValueChange={setFilterSection}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All Sections" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sections</SelectItem>
            <SelectItem value="none">None</SelectItem>
            {sections.map(s => (
              <SelectItem key={s.id} value={s.id.toString()}>
                {s.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select> */}
      </div>

      <table className="min-w-full border text-sm">
        <thead>
          <tr className="bg-gray-100">
            <th className="border p-2 text-center">Level</th>
            <th className="border p-2 text-left">Category</th>
            <th className="border p-2 text-left">Grade</th>
            {/* <th className="border p-2 text-left">Section</th> */}
            <th className="border p-2 text-center">Images</th>
            <th className="border p-2 text-left">Answer</th>
            <th className="border p-2 text-left">Hints</th>
            <th className="border p-2 text-center">Features</th>
            <th className="border p-2 text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(q => (
            <tr key={q.id}>
              <td className="border p-2 text-center">{q.level}</td>
              <td className="border p-2">
                {categories.find(c => c.id === q.category_id)?.name}
              </td>
              <td className="border p-2">
                {grades.find(g => g.id === q.grade_id)?.name}
              </td>
              {/* <td className="border p-2">
                {sections.find(s => s.id === q.section_id)?.name}
              </td> */}
              <td className="border p-2 text-center flex justify-center gap-2">
                <Image
                  src={q.image_1}
                  height={200}
                  width={100}
                  alt="img1"
                  className="object-cover rounded"
                />
                <Image
                  src={q.image_2}
                  alt="img2"
                  height={200}
                  width={100}
                  className="object-cover rounded"
                />
              </td>
              <td className="border p-2">{q.answer}</td>
              <td className="border p-2">{q.hints?.join(", ")}</td>
              <td className="border p-2 text-center">
                <div className="flex gap-1 justify-center flex-wrap">
                  {q.can_remove_letter && (
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">
                      Remove
                    </span>
                  )}
                  {q.can_reveal_letter && (
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded">
                      Reveal
                    </span>
                  )}
                  {q.can_reveal_first_word && (
                    <span className="text-xs bg-purple-100 text-purple-800 px-2 py-0.5 rounded">
                      First
                    </span>
                  )}
                </div>
              </td>
              <td className="border p-2 text-center flex gap-2 justify-center">
                <Button onClick={() => handleEdit(q)}>Edit</Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">Delete</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <div className="flex items-center gap-2">
                        <Trash2 className="size-5 text-destructive" />
                        <AlertDialogTitle>Delete</AlertDialogTitle>
                      </div>
                      <AlertDialogDescription>
                        This will permanently delete. This action cannot be
                        undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-white hover:bg-destructive/90"
                        onClick={() => handleDelete(q.id!)}>
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </td>
            </tr>
          ))}
          {filtered.length === 0 && !loading && (
            <tr>
              <td colSpan={9} className="text-center p-4 text-muted-foreground">
                No questions found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Add/Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit Question" : "Add New Question"}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[65vh]">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Category</Label>
                  <Select
                    value={form.category_id?.toString() || "none"}
                    onValueChange={async v => {
                      const newCategoryId = v === "none" ? null : Number(v);
                      const nextLevel = await getNextLevel(
                        newCategoryId,
                        form.grade_id ?? null,
                      );
                      setForm({
                        ...form,
                        category_id: newCategoryId,
                        level: nextLevel,
                      });
                    }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {categories.map(c => (
                        <SelectItem key={c.id} value={c.id.toString()}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Grade</Label>
                  <Select
                    value={form.grade_id?.toString() || "none"}
                    onValueChange={async v => {
                      const newGradeId = v === "none" ? null : Number(v);
                      const nextLevel = await getNextLevel(
                        form.category_id ?? null,
                        newGradeId,
                      );
                      setForm({
                        ...form,
                        grade_id: newGradeId,
                        level: nextLevel,
                      });
                    }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {grades.map(g => (
                        <SelectItem key={g.id} value={g.id.toString()}>
                          {g.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {/* <div>
                  <Label>Section</Label>
                  <Select
                    value={form.section_id?.toString() || "none"}
                    onValueChange={async v => {
                      const newSectionId = v === "none" ? null : Number(v);
                      setForm({
                        ...form,
                        section_id: newSectionId,
                      });
                    }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select section" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {sections.map(s => (
                        <SelectItem key={s.id} value={s.id.toString()}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div> */}
              </div>
              <Label>Level</Label>
              <Input
                type="number"
                value={form.level || ""}
                onChange={e =>
                  setForm({ ...form, level: Number(e.target.value) })
                }
              />
              <Label>Answer</Label>
              <Input
                placeholder="Answer (example: mangga or ice cream)"
                value={form.answer || ""}
                onChange={e => setForm({ ...form, answer: e.target.value })}
              />
              <Label>Tips (optional, comma separated)</Label>
              <Textarea
                placeholder="Short hints or hints"
                value={form.hints?.join(", ") || ""}
                onChange={e =>
                  setForm({
                    ...form,
                    hints: e.target.value.split(",").map(t => t.trim()),
                  })
                }
              />
              <div className="flex gap-4">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="can_remove_letter"
                    checked={form.can_remove_letter ?? false}
                    onChange={e =>
                      setForm({ ...form, can_remove_letter: e.target.checked })
                    }
                  />
                  <Label htmlFor="can_remove_letter">Can Remove Letter</Label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="can_reveal_letter"
                    checked={form.can_reveal_letter ?? false}
                    onChange={e =>
                      setForm({ ...form, can_reveal_letter: e.target.checked })
                    }
                  />
                  <Label htmlFor="can_reveal_letter">Can Reveal Letter</Label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="can_reveal_first_word"
                    checked={form.can_reveal_first_word ?? false}
                    onChange={e =>
                      setForm({
                        ...form,
                        can_reveal_first_word: e.target.checked,
                      })
                    }
                  />
                  <Label htmlFor="can_reveal_first_word">
                    Can Reveal First Word
                  </Label>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label>Remove Letter Limit</Label>
                  <Input
                    type="number"
                    value={form.remove_letter_limit ?? ""}
                    onChange={e =>
                      setForm({
                        ...form,
                        remove_letter_limit: e.target.value
                          ? Number(e.target.value)
                          : null,
                      })
                    }
                  />
                </div>
                <div className="flex-1">
                  <Label>Reveal Letter Limit</Label>
                  <Input
                    type="number"
                    value={form.reveal_letter_limit ?? ""}
                    onChange={e =>
                      setForm({
                        ...form,
                        reveal_letter_limit: e.target.value
                          ? Number(e.target.value)
                          : null,
                      })
                    }
                  />
                </div>
              </div>
              <div>
                <Label>Image 1</Label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={e => setImage1(e.target.files?.[0] || null)}
                />
                {editing?.image_1 && !image1 && (
                  <Image
                    src={editing.image_1}
                    height={200}
                    width={100}
                    alt="img1"
                    className="object-cover mt-2 rounded"
                  />
                )}
              </div>
              <div>
                <Label>Image 2</Label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={e => setImage2(e.target.files?.[0] || null)}
                />
                {editing?.image_2 && !image2 && (
                  <Image
                    src={editing.image_2}
                    height={200}
                    width={100}
                    alt="img2"
                    className="object-cover mt-2 rounded"
                  />
                )}
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={loading}>
                  {editing ? "Update" : "Save"}
                </Button>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
