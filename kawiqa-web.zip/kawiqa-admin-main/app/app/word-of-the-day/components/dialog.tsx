"use client";

import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { WordOfTheDay } from "../hooks/useWOTD";
import Image from "next/image";
import { supabase } from "@/lib/supabase/client";
import { toast } from "sonner";
import { ScrollArea } from "@/components/ui/scroll-area";

interface WOTDDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  form?: Partial<WordOfTheDay>;
  onChange?: (key: keyof WordOfTheDay, value: any) => void;
  onSave?: () => void;
  isSaving?: boolean;
  formErrors?: {
    word_ph?: string;
    word_en?: string;
    date?: string;
  };
}

const DIFFICULTIES = ["EASY", "MEDIUM", "HARD", "EXPERT"];

export const WOTDDialog: React.FC<WOTDDialogProps> = ({
  open,
  onOpenChange,
  form,
  onChange,
  onSave,
  isSaving,
  formErrors,
}) => {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const handleImageUpload = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    try {
      const file = event.target.files?.[0];
      if (!file) return;

      setUploading(true);

      const fileExt = file.name.split(".").pop();
      const fileName = file?.name ?? new Date() + (fileExt ?? ".png");
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from("word_of_the_day")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from("word_of_the_day")
        .getPublicUrl(filePath);

      if (data?.publicUrl) {
        console.log(data.publicUrl);

        setPreview(data.publicUrl);
        onChange?.("picture", data.publicUrl);
      }
    } catch (error: any) {
      console.error("Error uploading image:", error.message);
      toast.error("Something went wrong!");
    } finally {
      setUploading(false);
    }
  };

  useEffect(() => {
    if (!form?.picture) return;
    setPreview(form?.picture);
  }, [form?.picture]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Word of the Day</DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[50vh] pr-4">
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>
                Date <span className="text-destructive">*</span>
              </Label>
              <Input
                type="date"
                value={form?.date ?? ""}
                onChange={e => onChange?.("date", e.target.value)}
                className={formErrors?.date ? "border-destructive" : ""}
              />
              {formErrors?.date && (
                <p className="text-sm text-destructive">{formErrors.date}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Word (Filipino) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form?.word_ph ?? ""}
                onChange={e => onChange?.("word_ph", e.target.value)}
                placeholder="e.g., Tumpak"
                className={formErrors?.word_ph ? "border-destructive" : ""}
              />
              {formErrors?.word_ph && (
                <p className="text-sm text-destructive">{formErrors.word_ph}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>
                Word (English) <span className="text-destructive">*</span>
              </Label>
              <Input
                value={form?.word_en ?? ""}
                onChange={e => onChange?.("word_en", e.target.value)}
                placeholder="e.g., Correct"
                className={formErrors?.word_en ? "border-destructive" : ""}
              />
              {formErrors?.word_en && (
                <p className="text-sm text-destructive">{formErrors.word_en}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Phonetic</Label>
              <Input
                value={form?.phonetic ?? ""}
                onChange={e => onChange?.("phonetic", e.target.value)}
                placeholder="e.g., /tum·pak/"
              />
            </div>

            <div className="space-y-2">
              <Label>Tips / Usage</Label>
              <Textarea
                value={form?.tips ?? ""}
                onChange={e => onChange?.("tips", e.target.value)}
                placeholder="Give a short explanation or tip"
              />
            </div>

            <div className="space-y-2">
              <Label>Difficulty</Label>
              <Select
                value={form?.difficulty ?? "EASY"}
                onValueChange={v => onChange?.("difficulty", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select difficulty" />
                </SelectTrigger>
                <SelectContent>
                  {DIFFICULTIES.map(d => (
                    <SelectItem key={d} value={d}>
                      {d}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Picture</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                disabled={uploading}
              />
              {preview && (
                <div className="mt-3">
                  <Image
                    src={preview}
                    alt="Preview"
                    width={400}
                    height={200}
                    className="rounded-md border object-cover"
                  />
                </div>
              )}
            </div>
          </div>
        </ScrollArea>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSaving || uploading}>
            Cancel
          </Button>
          <Button onClick={onSave} disabled={isSaving || uploading}>
            {isSaving ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
