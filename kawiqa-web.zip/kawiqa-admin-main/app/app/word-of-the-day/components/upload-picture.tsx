"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import useWOTD from "../hooks/useWOTD";

export function WOTDPictureUpload() {
  const { uploadPicture } = useWOTD();
  const [file, setFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string>("");

  const handleUpload = async () => {
    if (!file) return alert("Please select a file first.");
    try {
      const url = await uploadPicture(file);
      setImageUrl(url);
    } catch (err) {
      console.error(err);
      alert("Failed to upload image.");
    }
  };

  return (
    <div className="space-y-4">
      <Input
        type="file"
        accept="image/*"
        onChange={e => {
          const selected = e.target.files?.[0];
          if (selected) setFile(selected);
        }}
      />
      <Button onClick={handleUpload}>Upload Image</Button>

      {imageUrl && (
        <div className="mt-4">
          <p className="font-semibold">Preview:</p>
          <img
            src={imageUrl}
            alt="Word of the Day"
            className="rounded-md border w-64 h-auto mt-2"
          />
        </div>
      )}
    </div>
  );
}
