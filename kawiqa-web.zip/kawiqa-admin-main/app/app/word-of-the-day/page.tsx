"use client";

import React, { useEffect, useMemo, useState } from "react";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import useWOTD, { WordOfTheDay } from "./hooks/useWOTD";
import { Loading } from "@/components/loading";
import { WOTDDialog } from "./components/dialog";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

export default function WordOfTheDayPage() {
  const {
    isLoading,
    words,
    fetchWordByDate,
    addWord,
    updateWord,
    deleteWord,
    fetchWords,
  } = useWOTD();
  const today = format(new Date(), "yyyy-MM-dd");

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<WordOfTheDay | null>(null);
  const [form, setForm] = useState<Partial<WordOfTheDay>>({
    date: today,
    difficulty: "EASY",
  });
  const [search, setSearch] = useState("");
  const [formErrors, setFormErrors] = useState<{
    word_ph?: string;
    word_en?: string;
    date?: string;
  }>({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchWords();
    fetchWordByDate(today).catch(() => {});
  }, []);

  useEffect(() => {
    if (!open) {
      setEditing(null);
      setForm({ date: today, difficulty: "EASY" });
      setFormErrors({});
    }
  }, [open]);

  const todayWord = useMemo(
    () => words?.find(w => w.date === today) ?? null,
    [words, today],
  );

  const filteredWords = useMemo(() => {
    if (!search.trim()) return words;
    const s = search.toLowerCase();
    return words?.filter(
      w =>
        w.word_ph.toLowerCase().includes(s) ||
        w.word_en.toLowerCase().includes(s) ||
        w.difficulty.toLowerCase().includes(s),
    );
  }, [search, words]);

  const handleChange = (key: keyof WordOfTheDay, value: any) => {
    setForm(prev => ({ ...prev, [key]: value }));
    // Clear error for this field
    const errorKey = key as keyof typeof formErrors;
    if (formErrors[errorKey]) {
      setFormErrors(prev => ({ ...prev, [errorKey]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const errors: { word_ph?: string; word_en?: string; date?: string } = {};
    
    if (!form.word_ph?.trim()) {
      errors.word_ph = "Word (Filipino) is required";
    } else if (form.word_ph.trim().length < 2) {
      errors.word_ph = "Word must be at least 2 characters";
    }
    
    if (!form.word_en?.trim()) {
      errors.word_en = "Word (English) is required";
    } else if (form.word_en.trim().length < 2) {
      errors.word_en = "Word must be at least 2 characters";
    }
    
    if (!form.date) {
      errors.date = "Date is required";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    setIsSaving(true);
    setFormErrors({});
    
    try {
      const payload: WordOfTheDay = {
        word_ph: form.word_ph!.trim(),
        word_en: form.word_en!.trim(),
        phonetic: form.phonetic?.trim() || null,
        tips: form.tips?.trim() || null,
        picture: form.picture || null,
        difficulty: (form.difficulty as "EASY" | "MEDIUM" | "HARD" | "EXPERT") ?? "EASY",
        date: form.date!,
      };

      if (editing && editing.id) {
        await updateWord(editing.id, payload);
      } else {
        await addWord(payload);
      }
      await fetchWords();
      setOpen(false);
    } catch (e: unknown) {
      console.error("Error saving word:", e);
      // Hook already shows error toast
    } finally {
      setIsSaving(false);
    }
  };

  const handleEdit = (w: WordOfTheDay) => {
    setEditing(w);
    setForm({ ...w });
    setFormErrors({});
    setOpen(true);
  };

  const handleDelete = async (id?: number) => {
    if (!id) return;
    await deleteWord(id);
    await fetchWords();
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Word of the Day</h1>
          <p className="text-sm text-muted-foreground">
            Daily vocabulary to learn, {format(new Date(), "MMM d, yyyy")}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={() => {
              setOpen(true);
              setEditing(null);
              setForm({ date: today, difficulty: "EASY" });
              setFormErrors({});
            }}>
            Add
          </Button>
          <Button variant="outline" onClick={() => fetchWords()}>
            Refresh
          </Button>
        </div>
      </div>

      {isLoading && <Loading />}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Today card */}
        <Card>
          <CardHeader>
            <CardTitle>Today</CardTitle>
            <CardDescription>Featured word for today</CardDescription>
          </CardHeader>
          <CardContent>
            {todayWord ? (
              <div className="space-y-3">
                <div className="text-3xl font-extrabold">
                  {todayWord.word_ph}
                </div>
                <div className="text-lg text-muted-foreground">
                  {todayWord.word_en}
                </div>
                {todayWord.phonetic && (
                  <div className="text-sm">{todayWord.phonetic}</div>
                )}
                {todayWord.tips && (
                  <div className="text-sm text-foreground">
                    {todayWord.tips}
                  </div>
                )}
                <div className="flex items-center gap-2 mt-3">
                  <Button onClick={() => todayWord.id && handleEdit(todayWord)}>
                    Edit
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive">Delete</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <div className="flex items-center gap-2">
                          <Trash2 className="size-5 text-destructive" />
                          <AlertDialogTitle>Delete</AlertDialogTitle>
                        </div>
                        <AlertDialogDescription>
                          This will permanently delete. This action cannot be
                          undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-white hover:bg-destructive/90"
                          onClick={() => handleDelete(todayWord.id)}>
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">
                No word scheduled for today. Add one to feature.
              </div>
            )}
          </CardContent>
        </Card>

        {/* All words with search */}
        <Card className="md:col-span-2">
          <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
            <div>
              <CardTitle>All Words</CardTitle>
              <CardDescription>Manage word of the day entries</CardDescription>
            </div>
            <Input
              placeholder="Search word or difficulty..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full md:w-64"
            />
          </CardHeader>

          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Word (PH)</TableHead>
                  <TableHead>Word (EN)</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Difficulty</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredWords?.length ? (
                  filteredWords.map(w => (
                    <TableRow key={w.id}>
                      <TableCell>{w.word_ph}</TableCell>
                      <TableCell>{w.word_en}</TableCell>
                      <TableCell>{format(w.date, "MMM dd, yyyy")}</TableCell>
                      <TableCell>{w.difficulty}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleEdit(w)}>
                            Edit
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive">Delete</Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <div className="flex items-center gap-2">
                                  <Trash2 className="size-5 text-destructive" />
                                  <AlertDialogTitle>Delete</AlertDialogTitle>
                                </div>
                                <AlertDialogDescription>
                                  This will permanently delete. This action
                                  cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  className="bg-destructive text-white hover:bg-destructive/90"
                                  onClick={() => handleDelete(w.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-sm py-6">
                      No words found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <WOTDDialog
        open={open}
        onOpenChange={setOpen}
        form={form}
        onChange={handleChange}
        onSave={handleSave}
        isSaving={isSaving}
        formErrors={formErrors}
      />
    </div>
  );
}
