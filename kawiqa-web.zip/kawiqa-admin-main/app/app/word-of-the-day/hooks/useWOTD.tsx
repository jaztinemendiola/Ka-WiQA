import { useState } from "react";
import { supabase } from "@/lib/supabase/client";
import { useToggle } from "@uidotdev/usehooks";
import { toast } from "sonner";
import useAuditLogs from "@/hooks/useAuditLogs";

export type WordOfTheDay = {
  id?: number;
  word_ph: string;
  word_en: string;
  phonetic?: string | null;
  tips?: string | null;
  picture?: string | null;
  difficulty?: "EASY" | "MEDIUM" | "HARD" | "EXPERT" | null;
  date: string;
  created_at?: string;
};

const useWOTD = () => {
  const [isLoading, setLoading] = useToggle();
  const [words, setWords] = useState<WordOfTheDay[]>([]);
  const [word, setWord] = useState<WordOfTheDay | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { logEvent } = useAuditLogs();

  const addWord = async (data: WordOfTheDay) => {
    setLoading(true);
    try {
      const { data: inserted, error } = await supabase
        .from("word_of_the_day")
        .insert([data])
        .select()
        .single();

      if (error) throw error;
      setWords(prev => [...prev, inserted]);
      await logEvent("INSERT", undefined, "word_of_the_day", window.location.pathname, "success", `Added word: ${data.word_ph}`);
      toast.success("Success");
      return inserted;
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      console.error("Add Word Error:", errorMessage);
      toast.error("Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  const fetchWords = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("word_of_the_day")
        .select("*")
        .order("date", { ascending: false });

      if (error) throw error;
      setWords(data);
      return data;
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      console.error("Fetch Words Error:", errorMessage);
      toast.error("Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  const fetchWordByDate = async (date: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("word_of_the_day")
        .select("*")
        .eq("date", date)
        .maybeSingle();

      if (error) throw error;
      setWord(data);
      return data;
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      console.error("Fetch Word by Date Error:", errorMessage);
      toast.error("Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  const updateWord = async (id: number, updates: Partial<WordOfTheDay>) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("word_of_the_day")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      setWords(prev =>
        prev.map(item => (item.id === id ? { ...item, ...data } : item))
      );
      await logEvent("UPDATE", undefined, "word_of_the_day", window.location.pathname, "success", `Updated word ID: ${id}`);
      toast.success("Success");
      return data;
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      console.error("Update Word Error:", errorMessage);
      toast.error("Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  const deleteWord = async (id: number) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from("word_of_the_day")
        .delete()
        .eq("id", id);

      if (error) throw error;
      setWords(prev => prev.filter(item => item.id !== id));
      await logEvent("DELETE", undefined, "word_of_the_day", window.location.pathname, "success", `Deleted word ID: ${id}`);
      toast.success("Success");
      return true;
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      console.error("Delete Word Error:", errorMessage);
      toast.error("Something went wrong!");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const uploadPicture = async (file: File) => {
    try {
      setLoading(true);

      const fileExt = file.name.split(".").pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from("word_of_the_day")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const {
        data: { publicUrl },
      } = supabase.storage.from("word_of_the_day").getPublicUrl(filePath);

      return publicUrl;
    } catch (err) {
      console.error("Image upload error:", err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    isLoading,
    words,
    word,
    error,
    addWord,
    fetchWords,
    fetchWordByDate,
    updateWord,
    deleteWord,
    uploadPicture,
  };
};

export default useWOTD;
