"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { XIcon, FilterIcon } from "lucide-react";
import { supabase } from "@/lib/supabase/client";

interface User {
  id: string;
  fullname: string | null;
  email?: string;
}

interface Module {
  module: string;
}

export default function LogFilters({
  onApply,
  initialUser = "",
  initialModule = "",
  initialSearch = "",
  initialFrom = "",
  initialTo = "",
  initialStatus = "",
}: {
  onApply?: (filters: {
    user?: string;
    module?: string;
    search?: string;
    from?: string;
    to?: string;
    status?: string;
  }) => void;
  initialUser?: string;
  initialModule?: string;
  initialSearch?: string;
  initialFrom?: string;
  initialTo?: string;
  initialStatus?: string;
}) {
  const router = useRouter();

  const [users, setUsers] = useState<User[]>([]);
  const [modules, setModules] = useState<Module[]>([]);

  // Internal state for form inputs
  const [user, setUser] = useState(initialUser);
  const [module, setModule] = useState(initialModule);
  const [search, setSearch] = useState(initialSearch);
  const [from, setFrom] = useState(initialFrom);
  const [to, setTo] = useState(initialTo);
  const [status, setStatus] = useState(initialStatus);

  // Track if any filter has changed
  const changesMade = useRef(false);

  // Mark when any filter changes
  useEffect(() => {
    changesMade.current = true;
  }, [user, module, search, from, to]);

  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("active", true);

        if (!error && data) {
          setUsers(data);
        }
      } catch {}
    })();

    (async () => {
      try {
        const { data, error } = await supabase
          .from("audit_logs_v2")
          .select("module");

        if (!error && data) {
          const uniqueModules = [
            ...new Set(data.map(d => d.module).filter(Boolean)),
          ];

          setModules(uniqueModules.map(m => ({ module: m })));
        }
      } catch {}
    })();
  }, []);

  const applyFilters = useCallback(() => {
    changesMade.current = false;

    const params = new URLSearchParams();
    if (user && user !== "__all__") params.set("user", user);
    if (module && module !== "__all__") params.set("module", module);
    if (search) params.set("search", search);
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    if (status) params.set("status", status);

    const queryString = params.toString();
    const newURL = queryString ? `?${queryString}` : window.location.pathname;

    // Update URL without triggering a page reload
    router.push(newURL, { scroll: false });

    // Notify parent component to refetch
    if (onApply) {
      onApply({
        user: user !== "__all__" ? user : undefined,
        module: module !== "__all__" ? module : undefined,
        search: search || undefined,
        from: from || undefined,
        to: to || undefined,
        status: status || undefined,
      });
    }
  }, [router, onApply, user, module, search, from, to, status]);

  const clearFilters = useCallback(() => {
    setUser("__all__");
    setModule("__all__");
    setSearch("");
    setFrom("");
    setTo("");
    setStatus("");
    changesMade.current = false;

    router.push(window.location.pathname, { scroll: false });

    if (onApply) {
      onApply({});
    }
  }, [router, onApply]);

  const hasActiveFilters =
    (user && user !== "__all__") ||
    (module && module !== "__all__") ||
    search ||
    from ||
    to ||
    (status && status !== "__all__");

  return (
    <div className="flex flex-wrap items-end gap-4 p-4 bg-card rounded-lg border">
      {/* User Filter */}
      <div className="flex-1 min-w-[200px]">
        <label className="text-sm font-medium mb-2 block">User</label>
        <Select value={user} onValueChange={setUser}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All users" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All users</SelectItem>
            {users.map(u => (
              <SelectItem key={u.id} value={u.id}>
                {u.fullname || u.email || u.id}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Module Filter */}
      <div className="flex-1 min-w-[200px]">
        <label className="text-sm font-medium mb-2 block">Module</label>
        <Select value={module} onValueChange={setModule}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All modules" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All modules</SelectItem>
            {modules.map(m => (
              <SelectItem key={m.module} value={m.module}>
                {m.module}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Status Filter */}
      <div className="flex-1 min-w-[200px]">
        <label className="text-sm font-medium mb-2 block">Status</label>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="All status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Status</SelectItem>
            {["success", "error"].map(s => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Search */}
      <div className="flex-1 min-w-[200px]">
        <label className="text-sm font-medium mb-2 block">Search</label>
        <Input
          placeholder="Search logs..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* From Date */}
      <div className="flex-1 min-w-[200px]">
        <label className="text-sm font-medium mb-2 block">From Date</label>
        <Input
          type="date"
          value={from}
          onChange={e => setFrom(e.target.value)}
        />
      </div>

      {/* To Date */}
      <div className="flex-1 min-w-[200px]">
        <label className="text-sm font-medium mb-2 block">To Date</label>
        <Input type="date" value={to} onChange={e => setTo(e.target.value)} />
      </div>

      {/* Actions */}
      <div className="flex items-end gap-2">
        <Button
          variant="destructive"
          onClick={clearFilters}
          size="icon"
          title="Clear filters">
          <XIcon className="size-4" />
        </Button>
        <Button
          onClick={applyFilters}
          disabled={!hasActiveFilters}
          className="flex items-center gap-2">
          <FilterIcon className="size-4" />
          Apply
        </Button>
      </div>
    </div>
  );
}
