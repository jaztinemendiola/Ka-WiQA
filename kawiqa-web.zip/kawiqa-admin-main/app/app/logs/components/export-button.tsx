"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { DownloadIcon } from "lucide-react"

interface ExportButtonProps {
  searchParams: {
    user?: string
    module?: string
    search?: string
    from?: string
    to?: string
  }
}

export default function LogExport({ searchParams }: ExportButtonProps) {
  const [loading, setLoading] = useState(false)

  const exportToCSV = async () => {
    setLoading(true)
    try {
      // Build query string for export API
      const params = new URLSearchParams()
      if (searchParams.user) params.append("user", searchParams.user)
      if (searchParams.module) params.append("module", searchParams.module)
      if (searchParams.search) params.append("search", searchParams.search)
      if (searchParams.from) params.append("from", searchParams.from)
      if (searchParams.to) params.append("to", searchParams.to)

      const response = await fetch(`/api/logs/export?${params.toString()}`)
      
      if (!response.ok) {
        throw new Error("Export failed")
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `audit-logs-${new Date().toISOString().split("T")[0]}.csv`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error("Error exporting logs:", error)
      alert("Failed to export logs. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button onClick={exportToCSV} disabled={loading} variant="outline">
      <DownloadIcon className="size-4 mr-2" />
      {loading ? "Exporting..." : "Export CSV"}
    </Button>
  )
}
