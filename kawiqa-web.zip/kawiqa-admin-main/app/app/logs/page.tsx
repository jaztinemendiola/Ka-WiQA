"use client";

import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import LogFilters from "./components/filters";
import LogExport from "./components/export-button";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Loading } from "@/components/loading";
import { cn } from "@/lib/utils";

interface AuditLog {
  id: string;
  user_id: string | null;
  action: string;
  status: string;
  module: string;
  record_id: string | null;
  description: string | null;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
  user: {
    fullname: string | null;
  } | null;
}

const PAGE_SIZE = 10;

export default function LogsPage() {
  const searchParams = useSearchParams();

  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  // Fetch logs based on current URL params
  const fetchLogs = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const params = new URLSearchParams(searchParams.toString());
      params.set("page", searchParams.get("page") || "1");
      params.set("limit", PAGE_SIZE.toString());

      const response = await fetch(`/api/logs/list?${params.toString()}`);

      if (!response.ok) {
        throw new Error("Failed to fetch logs");
      }

      const data = await response.json();
      setLogs(data.logs || []);
      setTotalCount(data.totalCount || 0);
    } catch (err) {
      setError(err instanceof Error ? err : new Error("Unknown error"));
    } finally {
      setLoading(false);
    }
  }, [searchParams]);

  // Fetch on mount and when URL params change
  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  const buildPageURL = (pageNum: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", pageNum.toString());
    return `?${params.toString()}`;
  };

  // Convert URL params to filter object for LogExport
  const exportFilters = {
    user: searchParams.get("user") || undefined,
    module: searchParams.get("module") || undefined,
    search: searchParams.get("search") || undefined,
    from: searchParams.get("from") || undefined,
    to: searchParams.get("to") || undefined,
    status: searchParams.get("status") || undefined,
  };

  return (
    <div className="w-full space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Audit Logs</h1>
        <LogExport searchParams={exportFilters} />
      </div>

      <LogFilters />

      <Card className="overflow-x-auto">
        {loading ? (
          <Loading />
        ) : error ? (
          <p className="p-4 text-destructive">
            Error loading logs: {error.message}
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="font-bold whitespace-nowrap">
                  Date
                </TableHead>
                <TableHead className="font-bold whitespace-nowrap">
                  Module
                </TableHead>
                <TableHead className="font-bold whitespace-nowrap">
                  Status
                </TableHead>
                <TableHead className="font-bold">Activity</TableHead>
                <TableHead className="font-bold">Ip Address</TableHead>
                <TableHead className="font-bold">Device & Browser</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="text-center py-8 text-muted-foreground">
                    No audit logs found.
                  </TableCell>
                </TableRow>
              ) : (
                logs.map(log => (
                  <TableRow key={log.id}>
                    <TableCell className="whitespace-nowrap">
                      {format(new Date(log.created_at), "PPp")}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {log.module || "unknown"}
                    </TableCell>
                    <TableCell>
                      <code
                        className={cn(
                          "text-xs bg-muted px-2 py-1 rounded",
                          log.status === "error"
                            ? "bg-red-300"
                            : "bg-emerald-300",
                        )}>
                        {log.status}
                      </code>
                    </TableCell>
                    <TableCell className="max-w-md">
                      <pre className="whitespace-pre-wrap text-sm font-sans break-words">
                        {log.user?.fullname || "System"} -{" "}
                        {log.description || ""}
                      </pre>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {log.ip_address || ""}
                    </TableCell>
                    <TableCell className="whitespace-nowrap max-w-xs">
                      {log.user_agent || ""}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        )}
      </Card>

      {totalPages > 1 && !loading && (
        <Pagination>
          <PaginationContent>
            {page > 1 && (
              <PaginationItem>
                <PaginationPrevious href={buildPageURL(page - 1)} />
              </PaginationItem>
            )}

            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum: number;
              if (totalPages <= 5) {
                pageNum = i + 1;
              } else if (page <= 3) {
                pageNum = i + 1;
              } else if (page >= totalPages - 2) {
                pageNum = totalPages - 4 + i;
              } else {
                pageNum = page - 2 + i;
              }

              return (
                <PaginationItem key={pageNum}>
                  <PaginationLink
                    href={buildPageURL(pageNum)}
                    isActive={pageNum === page}>
                    {pageNum}
                  </PaginationLink>
                </PaginationItem>
              );
            })}

            {page < totalPages && (
              <PaginationItem>
                <PaginationNext href={buildPageURL(page + 1)} />
              </PaginationItem>
            )}
          </PaginationContent>
        </Pagination>
      )}

      <div className="text-sm text-muted-foreground text-center">
        Showing {logs.length} of {totalCount} logs
      </div>
    </div>
  );
}
