"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase/client";
import { toast } from "sonner";
import { useAuthStore } from "@/stores/auth";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Users,
  UserPlus,
  GraduationCap,
  BookOpen,
  Trophy,
  Activity,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export default function HomePage() {
  const { isAdmin, profile } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<{
    totalStudents: number;
    totalTeachers: number;
    newUsersLast7Days: number;
    newUsersLast30Days: number;
    activeStudents: number;
    activeTeachers: number;
    recentUsers: Array<{
      id: string;
      fullname: string | null;
      email: string;
      role: string;
      created_at: string;
      grade_name?: string;
      section_name?: string;
    }>;
    topPerformers: Array<{
      id: string;
      fullname: string | null;
      email: string;
      grade_name?: string;
      section_name?: string;
      totalScore: number;
    }>;
    gradeBreakdown: Record<string, number>;
    teacherStudents?: Array<{
      id: string;
      fullname: string | null;
      email: string;
      grade_name?: string;
      section_name?: string;
      spelling: number;
      picture_guess: number;
      total: number;
    }>;
    totalPoints?: number;
  } | null>(null);

  useEffect(() => {
    fetchAnalytics();
  }, [isAdmin, profile?.id]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      if (isAdmin) {
        const [studentsRes, teachersRes, recentRes] = await Promise.all([
          supabase
            .from("profiles")
            .select("id, active, created_at, grade_id, section_id", {
              count: "exact",
            })
            .eq("role", "student"),
          supabase
            .from("profiles")
            .select("id, active, created_at", { count: "exact" })
            .eq("role", "teacher"),
          supabase
            .from("profiles")
            .select("id, fullname, email, role, created_at")
            .order("created_at", { ascending: false })
            .limit(10),
        ]);

        const now = new Date();
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const thirtyDaysAgo = new Date(
          now.getTime() - 30 * 24 * 60 * 60 * 1000,
        );

        const allStudents = studentsRes.data || [];
        const allTeachers = teachersRes.data || [];

        const newUsers7Days = [...allStudents, ...allTeachers].filter(
          u => new Date(u.created_at) >= sevenDaysAgo,
        ).length;
        const newUsers30Days = [...allStudents, ...allTeachers].filter(
          u => new Date(u.created_at) >= thirtyDaysAgo,
        ).length;

        // Grade breakdown
        const { data: grades } = await supabase
          .from("grades")
          .select("id, name");
        const gradeBreakdown: Record<string, number> = {};
        if (grades) {
          for (const grade of grades) {
            const count = allStudents.filter(
              s => s.grade_id === grade.id,
            ).length;
            if (count > 0) gradeBreakdown[grade.name] = count;
          }
        }

        // Top performers with grade/section names - fetch all scores and aggregate
        const { data: scoresWithProfiles } = await supabase.from("user_scores")
          .select(`
            user_id,
            score,
            profiles!inner(
              id,
              fullname,
              email,
              grades!profiles_grade_id_fkey(name),
              sections!profiles_section_id_fkey(name)
            )
          `);

        const scoresMap = new Map<
          string,
          {
            id: string;
            fullname: string | null;
            email: string;
            grade_name?: string;
            section_name?: string;
            totalScore: number;
          }
        >();
        let totalPoints = 0;

        (scoresWithProfiles || []).forEach(item => {
          const userId = item.user_id;
          const profile = item.profiles;
          if (!scoresMap.has(userId)) {
            scoresMap.set(userId, {
              id: userId,
              fullname: profile?.fullname,
              email: profile?.email,
              grade_name: profile?.grades?.name,
              section_name: profile?.sections?.name,
              totalScore: 0,
            });
          }
          const entry = scoresMap.get(userId)!;
          const scoreVal = item.score || 0;
          entry.totalScore += scoreVal;
          totalPoints += scoreVal;
        });

        const topPerformers = Array.from(scoresMap.values())
          .sort((a, b) => b.totalScore - a.totalScore)
          .slice(0, 10);

        setData({
          totalStudents: studentsRes.count || 0,
          totalTeachers: teachersRes.count || 0,
          newUsersLast7Days: newUsers7Days,
          newUsersLast30Days: newUsers30Days,
          activeStudents: allStudents.filter(s => s.active).length,
          activeTeachers: allTeachers.filter(t => t.active).length,
          recentUsers: (recentRes.data || []).map(u => ({
            id: u.id,
            fullname: u.fullname,
            email: u.email,
            role: u.role,
            created_at: u.created_at,
          })),
          topPerformers,
          gradeBreakdown,
          totalPoints,
        });
      } else if (!isAdmin && profile?.id) {
        // Get teacher's assigned student IDs
        const { data: assignments } = await supabase
          .from("teacher_students")
          .select("student_id")
          .eq("teacher_id", profile.id);

        const studentIds = assignments?.map(a => a.student_id) || [];

        if (studentIds.length === 0) {
          setData({
            totalStudents: 0,
            totalTeachers: 0,
            newUsersLast7Days: 0,
            newUsersLast30Days: 0,
            activeStudents: 0,
            activeTeachers: 0,
            recentUsers: [],
            topPerformers: [],
            gradeBreakdown: {},
            teacherStudents: [],
            totalPoints: 0,
          });
          setLoading(false);
          return;
        }

        // Fetch student profiles with grade/section names
        const { data: students } = await supabase
          .from("profiles")
          .select(
            `
            id,
            fullname,
            email,
            active,
            created_at,
            grades!profiles_grade_id_fkey(name),
            sections!profiles_section_id_fkey(name)
          `,
          )
          .in("id", studentIds);

        if (!students) {
          setData({
            totalStudents: 0,
            totalTeachers: 0,
            newUsersLast7Days: 0,
            newUsersLast30Days: 0,
            activeStudents: 0,
            activeTeachers: 0,
            recentUsers: [],
            topPerformers: [],
            gradeBreakdown: {},
            teacherStudents: [],
            totalPoints: 0,
          });
          setLoading(false);
          return;
        }

        const [spellingAttemptsRes, pictureProgressRes, scoresRes] =
          await Promise.all([
            supabase
              .from("spelling_attempts")
              .select("user_id")
              .in("user_id", studentIds),
            supabase
              .from("picture_word_guess_question_progress")
              .select("user_id")
              .in("user_id", studentIds),
            supabase
              .from("user_scores")
              .select("user_id, score")
              .in("user_id", studentIds),
          ]);

        const activeStudentsCount = students.filter(
          s => s.active,
        ).length;

        // Build student progress map
        const studentProgressMap: Record<
          string,
          { spelling: number; picture_guess: number; total: number }
        > = {};

        (spellingAttemptsRes.data || []).forEach(attempt => {
          if (!studentProgressMap[attempt.user_id]) {
            studentProgressMap[attempt.user_id] = {
              spelling: 0,
              picture_guess: 0,
              total: 0,
            };
          }
          studentProgressMap[attempt.user_id].spelling += 1;
          studentProgressMap[attempt.user_id].total += 1;
        });

        (pictureProgressRes.data || []).forEach(p => {
          if (!studentProgressMap[p.user_id]) {
            studentProgressMap[p.user_id] = {
              spelling: 0,
              picture_guess: 0,
              total: 0,
            };
          }
          studentProgressMap[p.user_id].picture_guess += 1;
          studentProgressMap[p.user_id].total += 1;
        });

        // Aggregate scores per student
        const scoresMap = new Map<string, number>();
        (scoresRes.data || []).forEach(item => {
          const userId = item.user_id;
          const score = item.score || 0;
          scoresMap.set(userId, (scoresMap.get(userId) || 0) + score);
        });
        const scoresAgg = Array.from(scoresMap.entries()).map(([user_id, totalScore]) => ({ user_id, totalScore }));

        // Build teacherStudents array with progress
        const teacherStudents = students.map(s => ({
          id: s.id,
          fullname: s.fullname,
          email: s.email,
          grade_name: s.grades?.name,
          section_name: s.sections?.name,
          spelling: studentProgressMap[s.id]?.spelling || 0,
          picture_guess: studentProgressMap[s.id]?.picture_guess || 0,
          total: studentProgressMap[s.id]?.total || 0,
        }));

        // Top performers
        const topPerformers = teacherStudents
          .map(s => ({
            ...s,
            totalScore:
              scoresAgg.find(sa => sa.user_id === s.id)?.totalScore || 0,
          }))
          .filter(s => s.totalScore > 0)
          .sort((a, b) => b.totalScore - a.totalScore)
          .slice(0, 10);

        // Grade breakdown
        const gradeBreakdown: Record<string, number> = {};
        students.forEach(s => {
          const gradeName = s.grades?.name || "No Grade";
          gradeBreakdown[gradeName] = (gradeBreakdown[gradeName] || 0) + 1;
        });

        setData({
          totalStudents: students.length,
          totalTeachers: 0,
          newUsersLast7Days: 0,
          newUsersLast30Days: 0,
          activeStudents: activeStudentsCount,
          activeTeachers: 0,
          recentUsers: students.slice(0, 10).map(s => ({
            id: s.id,
            fullname: s.fullname,
            email: s.email,
            role: "student",
            created_at: s.created_at,
            grade_name: s.grades?.name,
            section_name: s.sections?.name,
          })),
          topPerformers,
          gradeBreakdown,
          teacherStudents,
          totalPoints: 0,
        });
      }
    } catch (error) {
      console.error("Error fetching analytics:", error);
      toast.error("Failed to load analytics");
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({
    title,
    value,
    description,
    icon: Icon,
  }: {
    title: string;
    value: number | string;
    description?: string;
    icon: LucideIcon;
  }) => {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            {title}
          </CardTitle>
          <Icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{value}</div>
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Dashboard</h1>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-3/4" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-1/4" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <Badge variant={isAdmin ? "default" : "secondary"}>
          {isAdmin ? "Administrator" : "Teacher"} View
        </Badge>
      </div>

      {isAdmin ? (
        <>
          {/* Admin Statistics Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <StatCard
              title="Total Students"
              value={data?.totalStudents || 0}
              description={`${data?.activeStudents || 0} active`}
              icon={Users}
            />
            <StatCard
              title="Total Teachers"
              value={data?.totalTeachers || 0}
              description={`${data?.activeTeachers || 0} active`}
              icon={GraduationCap}
            />
            <StatCard
              title="New Users (7d)"
              value={data?.newUsersLast7Days || 0}
              description="Last 7 days"
              icon={UserPlus}
            />
            <StatCard
              title="Total Points"
              value={data?.totalPoints?.toLocaleString() || 0}
              description="All games"
              icon={Trophy}
            />
          </div>

          {/* Recent Users Table */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Users</CardTitle>
              <CardDescription>
                Latest registered users in the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data?.recentUsers.map(user => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">
                        {user.fullname || "N/A"}
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            user.role === "admin"
                              ? "destructive"
                              : user.role === "teacher"
                                ? "default"
                                : "secondary"
                          }>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(user.created_at).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                  {(!data?.recentUsers || data.recentUsers.length === 0) && (
                    <TableRow>
                      <TableCell
                        colSpan={4}
                        className="text-center text-muted-foreground">
                        No users found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Top Performers Table */}
          <Card>
            <CardHeader>
              <CardTitle>Top Performers</CardTitle>
              <CardDescription>
                Highest cumulative scores across all games
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rank</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead>Total Score</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data?.topPerformers.map((performer, index) => (
                    <TableRow key={performer.id}>
                      <TableCell className="font-medium">
                        #{index + 1}
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">
                            {performer.fullname || "Unknown"}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {performer.email}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{performer.grade_name || "-"}</TableCell>
                      <TableCell>{performer.section_name || "-"}</TableCell>
                      <TableCell className="font-semibold">
                        {performer.totalScore.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                  {(!data?.topPerformers ||
                    data.topPerformers.length === 0) && (
                    <TableRow>
                      <TableCell
                        colSpan={5}
                        className="text-center text-muted-foreground">
                        No score data available yet
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Grade/Section Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Grade Distribution</CardTitle>
              <CardDescription>
                Student and teacher distribution across grades
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Grade</TableHead>
                    <TableHead className="text-right">Students</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(data?.gradeBreakdown || {}).map(
                    ([grade, count]) => (
                      <TableRow key={grade}>
                        <TableCell className="font-medium">{grade}</TableCell>
                        <TableCell className="text-right">
                          <Badge variant="outline">{count} students</Badge>
                        </TableCell>
                      </TableRow>
                    ),
                  )}
                  {Object.keys(data?.gradeBreakdown || {}).length === 0 && (
                    <TableRow>
                      <TableCell
                        colSpan={2}
                        className="text-center text-muted-foreground">
                        No grade data available
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          {/* Teacher Statistics Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <StatCard
              title="My Students"
              value={data?.totalStudents || 0}
              description={`${data?.activeStudents || 0} active`}
              icon={Users}
            />
            <StatCard
              title="Classes"
              value={Object.keys(data?.gradeBreakdown || {}).length || 0}
              description="Active grades"
              icon={BookOpen}
            />
            <StatCard
              title="Total Submissions"
              value={
                data?.teacherStudents?.reduce((sum, s) => sum + s.total, 0) || 0
              }
              description="Game attempts"
              icon={Activity}
            />
            <StatCard
              title="Top Student Score"
              value={data?.topPerformers[0]?.totalScore.toLocaleString() || 0}
              description="Highest score"
              icon={Trophy}
            />
          </div>

          {/* Student Progress Table */}
          <Card>
            <CardHeader>
              <CardTitle>My Students Progress</CardTitle>
              <CardDescription>
                Overall progress and performance of assigned students
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead className="text-right">Spelling</TableHead>
                    <TableHead className="text-right">Picture Guess</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data?.teacherStudents && data.teacherStudents.length > 0 ? (
                    data.teacherStudents.map(student => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">
                          <div>
                            <div>{student.fullname || "Unknown"}</div>
                            <div className="text-sm text-muted-foreground">
                              {student.email}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{student.grade_name || "-"}</TableCell>
                        <TableCell>{student.section_name || "-"}</TableCell>
                        <TableCell className="text-right font-medium">
                          {student.spelling}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {student.picture_guess}
                        </TableCell>
                        <TableCell className="text-right font-bold">
                          {student.total}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className="bg-green-50 text-green-700 border-green-200">
                            Active
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={7}
                        className="text-center p-8 text-muted-foreground">
                        <div className="flex flex-col items-center gap-2">
                          <Users className="h-12 w-12 text-muted-foreground/50" />
                          <p>No students assigned yet.</p>
                          <p className="text-sm">
                            Go to the Students page to add students to your
                            class.
                          </p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Top Performers (Teacher View) */}
          <Card>
            <CardHeader>
              <CardTitle>Top Performers</CardTitle>
              <CardDescription>
                Students with the highest cumulative scores
              </CardDescription>
            </CardHeader>
            <CardContent>
              {data?.topPerformers && data.topPerformers.length > 0 ? (
                <div className="space-y-4">
                  {data.topPerformers.slice(0, 5).map((performer, index) => (
                    <div key={performer.id} className="flex items-center gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold">
                        #{index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">
                              {performer.fullname || "Unknown"}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {performer.grade_name} - {performer.section_name}
                            </p>
                          </div>
                          <div className="text-xl font-bold">
                            {performer.totalScore.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                  <Trophy className="h-12 w-12 mb-2 text-muted-foreground/50" />
                  <p>No score data available yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
