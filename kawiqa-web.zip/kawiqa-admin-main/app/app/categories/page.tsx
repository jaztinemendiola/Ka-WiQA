"use client";

import React, { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loading } from "@/components/loading";
import { CategoryDialog } from "./components/dialog";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/lib/supabase/client";
import Image from "next/image";
import { toast } from "sonner";

export interface Category {
  id: number;
  name: string;
  description: string | null;
  image: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [form, setForm] = useState<Partial<Category>>({});
  const [search, setSearch] = useState("");
  const [formErrors, setFormErrors] = useState<{ name?: string }>({});
  const [isSaving, setIsSaving] = useState(false);

  const fetchCategories = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("categories")
      .select("*")
      .order("name", { ascending: true });
    setIsLoading(false);

    if (error) {
      console.error("Error fetching categories:", error);
      return;
    }
    setCategories(data || []);
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleChange = (key: keyof Category, value: string | null) => {
    setForm(prev => ({ ...prev, [key]: value }));
    // Clear error for this field when user types
    if (key === 'name' && formErrors.name) {
      setFormErrors(prev => ({ ...prev, name: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const errors: { name?: string } = {};
    
    if (!form.name?.trim()) {
      errors.name = "Name is required";
    } else if (form.name.trim().length < 2) {
      errors.name = "Name must be at least 2 characters";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = async () => {
    // Validate first
    if (!validateForm()) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    setIsSaving(true);
    setFormErrors({});
    
    try {
      const payload = {
        name: form.name!.trim(),
        description: form.description?.trim() || null,
        image: form.image || null,
      };

      if (editing?.id) {
        const { error } = await supabase
          .from("categories")
          .update(payload)
          .eq("id", editing.id);

        if (error) {
          console.error("Error updating category:", error);
          toast.error("Failed to update category");
          throw error;
        }
      } else {
        const { error } = await supabase.from("categories").insert(payload);

        if (error) {
          console.error("Error adding category:", error);
          toast.error("Failed to add category");
          throw error;
        }
      }

      await fetchCategories();
      setOpen(false);
      toast.success(editing ? "Category updated successfully" : "Category added successfully");
    } catch (e: unknown) {
      console.error("Error saving category:", e);
      toast.error((String(e) as string) ?? "Something went wrong!");
    } finally {
      setIsSaving(false);
    }
  };

  const handleEdit = (category: Category) => {
    setEditing(category);
    setForm({ ...category });
    setFormErrors({});
    setOpen(true);
  };

  const handleDelete = async (id?: number) => {
    if (!id) return;

    const { error } = await supabase.from("categories").delete().eq("id", id);

    if (error) {
      console.error("Error deleting category:", error);
      return;
    }

    await fetchCategories();
  };

  const filtered = categories.filter(
    c =>
      !search.trim() ||
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.description?.toLowerCase().includes(search.toLowerCase()) ?? false),
  );

  return (
    <div className="flex flex-col h-full min-h-0 overflow-x-auto">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Categories</h1>
          <p className="text-sm text-muted-foreground">
            Manage vocabulary categories
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-1/2">
          <Input
            placeholder="Search category..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className=""
          />
          <Button
            onClick={() => {
              setEditing(null);
              setForm({ name: "", description: "", image: null });
              setFormErrors({});
              setOpen(true);
            }}>
            Add
          </Button>
        </div>
      </div>

      {isLoading && <Loading />}

      <Card className="flex-1 flex flex-col overflow-hidden">
        <CardHeader>
          <CardTitle>Category List</CardTitle>
          <CardDescription>All vocabulary categories</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 overflow-auto">
          <Table className="w-full min-w-[600px]">
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Image</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(category => (
                <TableRow key={category.id}>
                  <TableCell>{category.name}</TableCell>
                  <TableCell>{category.description}</TableCell>
                  <TableCell>
                    <Image
                      src={category.image!}
                      alt={category.id.toString()}
                      height={200}
                      width={100}
                      className="object-cover rounded"
                    />
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(category)}>
                        Edit
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive">Delete</Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <div className="flex items-center gap-2">
                              <Trash2 className="size-5 text-destructive" />
                              <AlertDialogTitle>Delete</AlertDialogTitle>
                            </div>
                            <AlertDialogDescription>
                              This will permanently delete. This action cannot
                              be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-white hover:bg-destructive/90"
                              onClick={() => handleDelete(category.id)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={3}
                    className="text-center text-muted-foreground">
                    No category found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <CategoryDialog
        open={open}
        onOpenChange={setOpen}
        form={form}
        onChange={handleChange}
        onSave={handleSave}
        isSaving={isSaving}
        formErrors={formErrors}
      />
    </div>
  );
}
