"use client";

import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Category } from "../page";
import { supabase } from "@/lib/supabase/client";
import Image from "next/image";
import { toast } from "sonner";

interface CategoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  form: Partial<Category>;
  onChange: (key: keyof Category, value: string | null) => void;
  onSave: () => void;
  isSaving: boolean;
  formErrors?: { name?: string };
}

export const CategoryDialog: React.FC<CategoryDialogProps> = ({
  open,
  onOpenChange,
  form,
  onChange,
  onSave,
  isSaving,
  formErrors,
}) => {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  React.useEffect(() => {
    if (form.image) {
      setPreview(form.image);
    } else {
      setPreview(null);
    }
  }, [form.image]);

  const handleImageUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    try {
      const file = event.target.files?.[0];
      if (!file) return;

      setUploading(true);

      // Delete old image if exists
      if (form.image) {
        const oldPath = form.image.split("/").slice(-2).join("/");
        await supabase.storage.from("categories").remove([oldPath]);
      }

      const categoryName = form.name?.toLowerCase() ?? "category";
      const fileExt = file.name.split(".").pop();
      const fileName = `${Date.now()}-${Math.random()}.${fileExt}`;
      const filePath = `${categoryName}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from("categories")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from("categories")
        .getPublicUrl(filePath);
      if (data?.publicUrl) {
        toast.success("Image uploaded!");
        setPreview(data.publicUrl);
        onChange("image", data.publicUrl);
      }
    } catch (error: any) {
      console.error("Image upload failed:", error.message);
      toast.error("Failed to upload image");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {form.id ? "Edit Category" : "Add Category"}
          </DialogTitle>
        </DialogHeader>

         <div className="space-y-4 py-4">
           <div className="space-y-2">
             <Label>
               Name <span className="text-destructive">*</span>
             </Label>
             <Input
               value={form.name ?? ""}
               onChange={e => onChange("name", e.target.value)}
               placeholder="e.g., Alpabeto"
               className={formErrors?.name ? "border-destructive" : ""}
             />
             {formErrors?.name && (
               <p className="text-sm text-destructive">{formErrors.name}</p>
             )}
           </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={form.description ?? ""}
              onChange={e => onChange("description", e.target.value)}
              placeholder="e.g., Filipino alphabet words"
            />
          </div>

          <div className="space-y-2">
            <Label>Image</Label>
            <Input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              disabled={uploading}
            />
            {(preview || form.image) && (
              <Image
                src={preview || form.image || ""}
                alt="Preview"
                width={200}
                height={100}
                className="rounded-md border object-cover mt-2"
              />
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isSaving}>
            Cancel
          </Button>
          <Button onClick={onSave} disabled={isSaving || uploading || !form.name}>
            {isSaving ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};