"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase/client";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loading } from "@/components/loading";
import { Switch } from "@/components/ui/switch";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Activity } from "@/components/activity";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useRouter } from "next/navigation";
import { PasswordInput } from "@/components/password-input";
import { useAuthStore } from "@/stores/auth";
import { EllipsisVertical } from "lucide-react";
import useAuditLogs, { getIP, getUserAgent } from "@/hooks/useAuditLogs";

interface Teacher {
  id?: string;
  fullname: string;
  firstname?: string;
  middlename?: string;
  lastname?: string;
  email?: string;
  role?: string;
  active?: boolean;
  grade_id?: number | null;
  section_id?: number | null;
  grade_name?: string;
  section_name?: string;
}

interface Grade {
  id: number;
  name: string;
}

interface Section {
  id: number;
  name: string;
  grade_id: number;
}

export default function TeachersPage() {
  const { logEvent } = useAuditLogs();
  const { isAdmin, user } = useAuthStore();
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [filteredSections, setFilteredSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Teacher | null>(null);
  const [form, setForm] = useState<Teacher>({
    fullname: "",
    firstname: "",
    middlename: "",
    lastname: "",
    email: "",
    grade_id: null,
    section_id: null,
  });
  const [search, setSearch] = useState("");
  const [inviteMode, setInviteMode] = useState(false);
  const [password, setPassword] = useState("");

  useEffect(() => {
    fetchTeachers();
    fetchGrades();
    fetchSections();
  }, []);

  const fetchTeachers = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("profiles")
      .select(
        `
        *,
        grades!profiles_grade_id_fkey(name),
        sections!profiles_section_id_fkey(name)
      `,
      )
      .eq("role", "teacher")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Something went wrong!");
    } else if (data) {
      const teachersWithNames = data
        .filter((t: any) => Boolean(t.fullname))
        .map((t: any) => ({
          ...t,
          grade_name: t.grades?.name,
          section_name: t.sections?.name,
        }));
      console.log("teachersWithNames", teachersWithNames);

      setTeachers(teachersWithNames);
    }
    setLoading(false);
  };

  const fetchGrades = async () => {
    const { data, error } = await supabase
      .from("grades")
      .select("*")
      .order("name");
    if (!error && data) setGrades(data);
  };

  const fetchSections = async () => {
    const { data, error } = await supabase
      .from("sections")
      .select("*")
      .order("name");
    if (!error && data) setSections(data);
  };

  // Update filteredSections whenever grade_id changes
  useEffect(() => {
    if (form.grade_id) {
      const filtered = sections.filter(s => s.grade_id === form.grade_id);
      setFilteredSections(filtered);
      // Reset section selection on grade change
      setForm(prev => ({ ...prev, section_id: null }));
    } else {
      setFilteredSections([]);
      setForm(prev => ({ ...prev, section_id: null }));
    }
  }, [form.grade_id, sections]);

  const handleSave = async () => {
    if (!editing && !form.email) {
      toast.error("Please fill all required fields");
      return;
    }

    // Require password for Add User mode only
    if (!editing && !inviteMode && !password) {
      toast.error("Password is required for Add User");
      return;
    }

    setLoading(true);
    try {
      if (editing) {
        // Update profile in database
        const { error } = await supabase
          .from("profiles")
          .update({
            firstname: form.firstname,
            middlename: form.middlename,
            lastname: form.lastname,
            grade_id: form.grade_id,
            section_id: form.section_id,
            email: form.email,
          })
          .eq("id", editing.id);

        if (error) throw error;

        // Update email in auth if changed
        if (form.email) {
          const updateResponse = await fetch("/api/users", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              userId: editing.id,
              email: form.email,
            }),
          });

          const updateResult = await updateResponse.json();
          if (updateResult.error) {
            throw new Error(updateResult.error);
          }
        }
      } else {
        // Call server-side API to create user with admin privileges
        const response = await fetch("/api/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: form.email,
            password: inviteMode ? null : password,
            firstname: form.firstname,
            middlename: form.middlename,
            lastname: form.lastname,
            grade_id: form.grade_id,
            section_id: form.section_id,
            role: "teacher",
          }),
        });

        const result = await response.json();
        if (result.error) {
          throw new Error(result.error);
        }
        if (!result.user) {
          throw new Error("User creation failed");
        }

        // Upsert profile using client-side supabase
        const { error: profileError } = await supabase.from("profiles").upsert({
          id: result.user.id,
          email: form.email,
          firstname: form.firstname,
          middlename: form.middlename,
          lastname: form.lastname,
          grade_id: form.grade_id,
          section_id: form.section_id,
        });

        if (profileError) throw profileError;
      }

      setOpen(false);
      setEditing(null);
      setForm({
        fullname: "",
        firstname: "",
        middlename: "",
        lastname: "",
        email: "",
        grade_id: null,
        section_id: null,
      });
      setInviteMode(false);
      setPassword("");
      fetchTeachers();
      toast.success(
        editing
          ? "Teacher updated successfully"
          : inviteMode
            ? "Invitation sent successfully"
            : "User added successfully",
      );
    } catch (e: unknown) {
      console.error("Error saving teacher:", e);
      toast.error((String(e) as string) ?? "Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (t: Teacher) => {
    setEditing(t);
    setForm({
      fullname: t.fullname || "",
      firstname: t.firstname || "",
      middlename: t.middlename || "",
      lastname: t.lastname || "",
      email: t.email || "",
      grade_id: t.grade_id ?? null,
      section_id: t.section_id ?? null,
    });
    setOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this teacher?")) return;
    await supabase.from("profiles").delete().eq("id", id);
    await fetchTeachers();
    toast.success("Success");
  };

  const handleToggleActive = async (id: string, current: boolean) => {
    await supabase.from("profiles").update({ active: !current }).eq("id", id);
    setTeachers(prev =>
      prev.map(t => (t.id === id ? { ...t, active: !current } : t)),
    );
    toast.success("Status updated successfully");
  };

  const handleSendResetPassword = async (t: Teacher) => {
    if (!t.email) {
      toast.error("Teacher has no email address");
      return;
    }
    setLoading(true);
    try {
      const response = await fetch("/api/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: t.email,
          actor_user_id: user?.id,
        }),
      });
      const result = await response.json();
      if (result.error) {
        await supabase.from("audit_logs_v2").insert([
          {
            actor_user_id: user?.id,
            actor_email: t.email,
            actor_role: "admin",
            target_user_id: t.id,
            action: "PASSWORD_RESET",
            module: "users",
            page: window.location.pathname,
            status: "error",
            description: "Reset password attempt failed.",
            ip_address: await getIP(),
            user_agent: getUserAgent(),
          },
        ]);
        throw new Error(result.error);
      }
      toast.success("Password reset email sent successfully");
      await supabase.from("audit_logs_v2").insert([
        {
          actor_user_id: user?.id,
          actor_email: t.email,
          actor_role: "admin",
          target_user_id: t.id,
          action: "PASSWORD_RESET",
          module: "users",
          page: window.location.pathname,
          status: "success",
          description: `Password reset email sent to ${t.email}`,
          ip_address: await getIP(),
          user_agent: getUserAgent(),
        },
      ]);
    } catch (e: unknown) {
      console.error("Error sending reset password:", e);
      toast.error((String(e) as string) ?? "Failed to send reset email");
    } finally {
      setLoading(false);
    }
  };

  const filtered = teachers.filter(t =>
    [t.email, t.firstname, t.lastname, t.grade_name, t.section_name]
      .join(" ")
      .toLowerCase()
      .includes(search.toLowerCase()),
  );

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-3xl font-bold">Teachers</h1>
        <div className="flex gap-2">
          <Input
            placeholder="Search by name or teacher number..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-64"
          />
          <Activity mode={isAdmin ? "visible" : "hidden"}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button>Add User</Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem
                  onClick={() => {
                    setInviteMode(false);
                    setEditing(null);
                    setForm({
                      fullname: "",
                      firstname: "",
                      middlename: "",
                      lastname: "",
                      email: "",
                      grade_id: null,
                      section_id: null,
                    });
                    setOpen(true);
                  }}>
                  Add User
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => {
                    setInviteMode(true);
                    setEditing(null);
                    setForm({
                      fullname: "",
                      firstname: "",
                      middlename: "",
                      lastname: "",
                      email: "",
                      grade_id: null,
                      section_id: null,
                    });
                    setOpen(true);
                  }}>
                  Invite User
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </Activity>
        </div>
      </div>

      {loading && <Loading />}

      <table className="min-w-full border text-sm">
        <thead>
          <tr className="bg-gray-100">
            <th className="border p-2 text-left">Email</th>
            <th className="border p-2 text-left">First Name</th>
            <th className="border p-2 text-left">Middle Name</th>
            <th className="border p-2 text-left">Last Name</th>
            <th className="border p-2 text-center">Active</th>
            <th className="border p-2 text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(t => (
            <tr key={t.id}>
              <td className="border p-2">{t.email}</td>
              <td className="border p-2">{t.firstname}</td>
              <td className="border p-2">{t.middlename}</td>
              <td className="border p-2">{t.lastname}</td>
              <td className="border p-2 text-center">
                <Switch
                  checked={!!t.active}
                  disabled={!isAdmin}
                  onCheckedChange={() => handleToggleActive(t.id!, !!t.active)}
                />
              </td>
              <td className="border p-2 text-center flex gap-2 justify-center">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon">
                      <EllipsisVertical />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-fit" align="start">
                    <Activity mode={isAdmin ? "visible" : "hidden"}>
                      <DropdownMenuItem onClick={() => handleEdit(t)}>
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleSendResetPassword(t)}>
                        Send Reset Password
                      </DropdownMenuItem>
                    </Activity>
                  </DropdownMenuContent>
                </DropdownMenu>
              </td>
            </tr>
          ))}
          {filtered.length === 0 && !loading && (
            <tr>
              <td colSpan={9} className="text-center p-4 text-muted-foreground">
                No teachers found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Add / Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editing
                ? "Edit Teacher"
                : inviteMode
                  ? "Invite Teacher"
                  : "Add Teacher"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* <div>
              <Label htmlFor="fullname">Fullname</Label>
              <Input
                id="fullname"
                value={form.fullname}
                onChange={(e) =>
                  setForm({ ...form, fullname: e.target.value })
                }
              />
            </div> */}
            <div>
              <Label htmlFor="firstname">First Name</Label>
              <Input
                id="firstname"
                value={form.firstname || ""}
                onChange={e => setForm({ ...form, firstname: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="middlename">Middle Name</Label>
              <Input
                id="middlename"
                value={form.middlename || ""}
                onChange={e => setForm({ ...form, middlename: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="lastname">Last Name</Label>
              <Input
                id="lastname"
                value={form.lastname || ""}
                onChange={e => setForm({ ...form, lastname: e.target.value })}
              />
            </div>

            {/* <div>
              <Label htmlFor="grade_id">Grade</Label>
              <Select
                onValueChange={value =>
                  setForm({ ...form, grade_id: value ? Number(value) : null })
                }
                value={form.grade_id ? String(form.grade_id) : ""}>
                <SelectTrigger id="grade_id" className="w-full">
                  <SelectValue placeholder="Select Grade" />
                </SelectTrigger>
                <SelectContent>
                  {grades.map(g => (
                    <SelectItem key={g.id} value={String(g.id)}>
                      {g.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="section_id">Section</Label>
              <Select
                onValueChange={value =>
                  setForm({ ...form, section_id: value ? Number(value) : null })
                }
                value={form.section_id ? String(form.section_id) : ""}
                disabled={!form.grade_id}>
                <SelectTrigger id="section_id" className="w-full">
                  <SelectValue
                    placeholder={
                      form.grade_id ? "Select Section" : "Select Grade first"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {filteredSections.length > 0 ? (
                    filteredSections.map(s => (
                      <SelectItem key={s.id} value={String(s.id)}>
                        {s.name}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="0" disabled>
                      No sections available
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div> */}

            <div>
              <Label htmlFor="email">{editing ? "New Email" : "Email"}</Label>
              <Input
                id="email"
                type="email"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder={editing ? "Leave empty to keep current email" : ""}
              />
            </div>

            {!editing && !inviteMode && (
              <div>
                <Label htmlFor="password">Password</Label>
                <PasswordInput
                  id="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
              </div>
            )}

            {!editing && inviteMode && (
              <p className="text-sm text-muted-foreground">
                An invitation email will be sent to the user.
              </p>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={loading}>
                {editing ? "Update" : "Save"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
