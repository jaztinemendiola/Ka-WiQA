"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase/client"
import { toast } from "sonner"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useAuthStore } from "@/stores/auth"
import { SaveIcon, UsersIcon } from "lucide-react"

interface Profile {
  id: string
  fullname: string | null
  firstname: string | null
  lastname: string | null
  email: string | null
  role: string
}

export default function AssignStudentsPage() {
  const router = useRouter()
  const { isAdmin } = useAuthStore()

  const [teachers, setTeachers] = useState<Profile[]>([])
  const [students, setStudents] = useState<Profile[]>([])
  const [selectedTeacher, setSelectedTeacher] = useState<string>("")
  const [selectedStudents, setSelectedStudents] = useState<Set<string>>(new Set())
  const [saving, setSaving] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")

  // Redirect non-admin users
  useEffect(() => {
    if (!isAdmin) {
      router.push("/app/home")
      return
    }
  }, [isAdmin, router])

  // Fetch all teachers
  const fetchTeachers = async () => {
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("role", "teacher")
        .order("fullname", { ascending: true })

      if (error) throw error
      setTeachers(data || [])
    } catch (error) {
      console.error("Error fetching teachers:", error)
      toast.error("Failed to load teachers")
    }
  }

  // Fetch all students
  const fetchStudents = async () => {
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("role", "student")
        .order("fullname", { ascending: true })

      if (error) throw error
      setStudents(data || [])
    } catch (error) {
      console.error("Error fetching students:", error)
      toast.error("Failed to load students")
    }
  }

  // Fetch assignments for selected teacher
  const fetchAssignments = async (teacherId: string) => {
    try {
      const { data, error } = await supabase
        .from("teacher_students")
        .select("student_id")
        .eq("teacher_id", teacherId)

      if (error) throw error
      const assignedIds = new Set((data || []).map(a => a.student_id))
      setSelectedStudents(assignedIds)
    } catch (error) {
      console.error("Error fetching assignments:", error)
      toast.error("Failed to load assignments")
    }
  }

  useEffect(() => {
    if (isAdmin) {
      fetchTeachers()
      fetchStudents()
    }
  }, [isAdmin])

  useEffect(() => {
    if (selectedTeacher) {
      fetchAssignments(selectedTeacher)
    } else {
      setSelectedStudents(new Set())
    }
  }, [selectedTeacher])

  const handleTeacherChange = (teacherId: string) => {
    setSelectedTeacher(teacherId)
  }

  const handleStudentToggle = (studentId: string, checked: boolean) => {
    setSelectedStudents(prev => {
      const next = new Set(prev)
      if (checked) {
        next.add(studentId)
      } else {
        next.delete(studentId)
      }
      return next
    })
  }

  const handleSelectAll = () => {
    const filteredStudents = getFilteredStudents()
    if (selectedStudents.size === filteredStudents.length) {
      setSelectedStudents(new Set())
    } else {
      setSelectedStudents(new Set(filteredStudents.map(s => s.id)))
    }
  }

  const handleSave = async () => {
    if (!selectedTeacher) {
      toast.error("Please select a teacher first")
      return
    }

    setSaving(true)
    try {
      // Get current assignments from server (to avoid race conditions)
      const { data: current, error: fetchError } = await supabase
        .from("teacher_students")
        .select("student_id")
        .eq("teacher_id", selectedTeacher)

      if (fetchError) throw fetchError

      const currentIds = new Set((current || []).map(a => a.student_id))
      const newIds = selectedStudents

      // Determine which assignments to add and remove
      const toAdd = Array.from(newIds).filter(id => !currentIds.has(id))
      const toRemove = Array.from(currentIds).filter(id => !newIds.has(id))

      // Perform deletions
      if (toRemove.length > 0) {
        const { error: deleteError } = await supabase
          .from("teacher_students")
          .delete()
          .eq("teacher_id", selectedTeacher)
          .in("student_id", toRemove)

        if (deleteError) throw deleteError
      }

      // Perform inserts
      if (toAdd.length > 0) {
        const inserts = toAdd.map(student_id => ({
          teacher_id: selectedTeacher,
          student_id,
        }))
        const { error: insertError } = await supabase
          .from("teacher_students")
          .insert(inserts)

        if (insertError) throw insertError
      }

      toast.success(`Updated ${toAdd.length + toRemove.length} assignments`)

      // Refresh assignments from server
      await fetchAssignments(selectedTeacher)
    } catch (error) {
      console.error("Error saving assignments:", error)
      toast.error("Failed to save assignments")
    } finally {
      setSaving(false)
    }
  }

  const getFilteredStudents = () => {
    return students.filter(s => 
      s.fullname?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.email?.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }

  const allFilteredSelected = getFilteredStudents().length > 0 && 
    getFilteredStudents().every(s => selectedStudents.has(s.id))

  if (!isAdmin) {
    return null
  }

  return (
    <div className="w-full space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Assign Students to Teachers</h1>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <UsersIcon className="size-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">Assignment Configuration</h2>
          </div>

          {/* Teacher Selection */}
          <div className="max-w-xs">
            <Label htmlFor="teacher-select">Select Teacher</Label>
            <Select value={selectedTeacher} onValueChange={handleTeacherChange}>
              <SelectTrigger id="teacher-select">
                <SelectValue placeholder="Choose a teacher..." />
              </SelectTrigger>
              <SelectContent>
                {teachers.map(teacher => (
                  <SelectItem key={teacher.id} value={teacher.id!}>
                    {teacher.fullname || teacher.email || teacher.id}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedTeacher && (
            <>
              {/* Search */}
              <div>
                <Label>Search Students</Label>
                <Input
                  placeholder="Search by name or email..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="max-w-xs"
                />
              </div>

              {/* Students List */}
              <div className="border rounded-lg">
                <div className="p-3 border-b bg-muted/50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="select-all"
                        checked={allFilteredSelected}
                        onCheckedChange={handleSelectAll}
                      />
                      <Label htmlFor="select-all" className="cursor-pointer">
                        Select All ({getFilteredStudents().length} students)
                      </Label>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {selectedStudents.size} selected
                    </span>
                  </div>
                </div>

                <div className="max-h-[400px] overflow-y-auto">
                  {getFilteredStudents().length === 0 ? (
                    <div className="p-4 text-center text-muted-foreground">
                      No students found
                    </div>
                  ) : (
                    <div className="p-2">
                      {getFilteredStudents().map(student => (
                        <div
                          key={student.id}
                          className="flex items-center gap-2 p-2 hover:bg-accent rounded-md"
                        >
                          <Checkbox
                            id={student.id}
                            checked={selectedStudents.has(student.id)}
                            onCheckedChange={(checked) =>
                              handleStudentToggle(student.id, checked as boolean)
                            }
                          />
                          <Label
                            htmlFor={student.id}
                            className="flex-1 cursor-pointer"
                          >
                            <div className="font-medium">
                              {student.fullname || "Unknown"}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {student.email}
                            </div>
                          </Label>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Save Button */}
              <div className="flex justify-end pt-4">
                <Button onClick={handleSave} disabled={saving} size="lg">
                  <SaveIcon className="size-4 mr-2" />
                  {saving ? "Saving..." : "Save Assignments"}
                </Button>
              </div>
            </>
          )}
        </div>
      </Card>
    </div>
  )
}
