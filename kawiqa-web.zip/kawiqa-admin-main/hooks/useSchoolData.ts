import { supabase } from "@/lib/supabase/client";
import { Database } from "@/types/database.types";
import { useState } from "react";

export type Grade = Database["public"]["Tables"]["grades"]["Row"];
export type Section = Database["public"]["Tables"]["sections"]["Row"];

const useSchoolData = () => {
  const [grades, setGrades] = useState<Grade[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = async () => {
    setLoading(true);

    const [gradesRes, sectionsRes] = await Promise.all([
      supabase.from("grades").select("*").order("id"),
      supabase.from("sections").select("*").order("id"),
    ]);

    if (gradesRes.error || sectionsRes.error) {
      setError(
        gradesRes.error?.message ||
          sectionsRes.error?.message ||
          "Error fetching data",
      );
    } else {
      setGrades(gradesRes.data || []);
      setSections(sectionsRes.data || []);
    }

    setLoading(false);
  };

  // helper: filter sections by grade
  const getSectionsByGrade = (gradeId?: number) => {
    if (!gradeId) return sections;
    return sections.filter(s => s.grade_id === gradeId);
  };

  // helper: get single grade
  const getGradeById = (id?: number) => grades.find(g => g.id === id);

  // helper: get single section
  const getSectionById = (id?: number) => sections.find(s => s.id === id);

  return {
    grades,
    sections,
    loading,
    error,
    refetch: fetchAll,

    // helpers
    getSectionsByGrade,
    getGradeById,
    getSectionById,
  };
};

export default useSchoolData;
