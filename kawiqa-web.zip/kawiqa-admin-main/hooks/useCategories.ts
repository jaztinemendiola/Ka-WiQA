"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase/client";
import useAuditLogs from "@/hooks/useAuditLogs";

export interface Category {
  id: number;
  name: string;
}

const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const { logEvent } = useAuditLogs();

  const fetchCategories = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("categories")
      .select("id, name")
      .order("name", { ascending: true });
    setLoading(false);

    if (error) throw error;
    setCategories(data || []);
  };

  const addCategory = async (name: string) => {
    const { error } = await supabase.from("categories").insert({ name });
    if (error) throw error;
    await logEvent("INSERT", undefined, "categories", window.location.pathname, "success", `Added category: ${name}`);
    fetchCategories();
  };

  const updateCategory = async (id: number, name: string) => {
    const { error } = await supabase.from("categories").update({ name }).eq("id", id);
    if (error) throw error;
    await logEvent("UPDATE", undefined, "categories", window.location.pathname, "success", `Updated category ID: ${id}`);
    fetchCategories();
  };

  const deleteCategory = async (id: number) => {
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) throw error;
    await logEvent("DELETE", undefined, "categories", window.location.pathname, "success", `Deleted category ID: ${id}`);
    fetchCategories();
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return { categories, loading, fetchCategories, addCategory, updateCategory, deleteCategory };
};

export default useCategories;
