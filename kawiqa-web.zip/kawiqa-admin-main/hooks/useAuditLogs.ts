import { supabase } from "@/lib/supabase/client";
import { useAuthStore } from "@/stores/auth";

export type AuditAction =
  | "INSERT"
  | "UPDATE"
  | "DELETE"
  | "LOGIN"
  | "LOGOUT"
  | "OTHER";

export const getIP = async () => {
  const res = await fetch("https://api.ipify.org?format=json");
  const data = await res.json();
  return data.ip || "";
};

export const getUserAgent = (): string => {
  if (typeof window === "undefined") return "";

  const ua = navigator.userAgent;

  let browser = "Unknown Browser";
  let device = "Unknown Device";

  // Browser detection
  if (ua.includes("Chrome") && !ua.includes("Edg")) {
    browser = "Chrome";
  } else if (ua.includes("Safari") && !ua.includes("Chrome")) {
    browser = "Safari";
  } else if (ua.includes("Firefox")) {
    browser = "Firefox";
  } else if (ua.includes("Edg")) {
    browser = "Edge";
  }

  // Device / OS detection
  if (ua.includes("Mac OS X")) {
    device = "Mac";
  } else if (ua.includes("Windows")) {
    device = "Windows PC";
  } else if (ua.includes("Android")) {
    device = "Android";
  } else if (ua.includes("iPhone")) {
    device = "iPhone";
  } else if (ua.includes("iPad")) {
    device = "iPad";
  } else if (ua.includes("Linux")) {
    device = "Linux";
  }

  return `${device} • ${browser}`;
};

export default function useAuditLogs() {
  const { user } = useAuthStore();
  const logEvent = async (
    action: AuditAction,
    target_user_id?: string,
    module?: string,
    page?: string,
    status = "success",
    description?: string,
  ) => {
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser();

    await fetch("/api/log-event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        actor_user_id: user?.id || authUser?.id || null,
        target_user_id: target_user_id || undefined,
        action,
        module: module || undefined,
        page: page || undefined,
        status,
        description: description || undefined,
        ip_address: await getIP(),
        user_agent: getUserAgent(),
      }),
    });
  };

  const logUserAction = async (
    action: AuditAction,
    target_user_id?: string,
    description?: string,
  ) => {
    const user = await supabase.auth.getUser();
    const page =
      typeof window !== "undefined" ? window.location.pathname : undefined;

    await logEvent(
      action,
      target_user_id,
      "users",
      page,
      "success",
      description,
    );
  };

  return { logEvent, logUserAction };
}
