export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: Database["public"]["Enums"]["audit_action"]
          created_at: string
          description: string | null
          id: string
          record_id: string | null
          table_name: string
          user_id: string | null
        }
        Insert: {
          action: Database["public"]["Enums"]["audit_action"]
          created_at?: string
          description?: string | null
          id?: string
          record_id?: string | null
          table_name: string
          user_id?: string | null
        }
        Update: {
          action?: Database["public"]["Enums"]["audit_action"]
          created_at?: string
          description?: string | null
          id?: string
          record_id?: string | null
          table_name?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          created_at: string | null
          description: string | null
          id: number
          image: string | null
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: number
          image?: string | null
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: number
          image?: string | null
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      gameone_questions: {
        Row: {
          answer: string
          created_at: string | null
          id: number
          image_1: string
          image_2: string
          level: number
          random_letters: string[]
          tips: string[] | null
        }
        Insert: {
          answer: string
          created_at?: string | null
          id?: number
          image_1: string
          image_2: string
          level: number
          random_letters: string[]
          tips?: string[] | null
        }
        Update: {
          answer?: string
          created_at?: string | null
          id?: number
          image_1?: string
          image_2?: string
          level?: number
          random_letters?: string[]
          tips?: string[] | null
        }
        Relationships: []
      }
      gameone_user_help_attempts: {
        Row: {
          attempt_count: number | null
          created_at: string | null
          details: Json | null
          help_type: string
          id: number
          question_id: number | null
          user_id: string | null
        }
        Insert: {
          attempt_count?: number | null
          created_at?: string | null
          details?: Json | null
          help_type: string
          id?: number
          question_id?: number | null
          user_id?: string | null
        }
        Update: {
          attempt_count?: number | null
          created_at?: string | null
          details?: Json | null
          help_type?: string
          id?: number
          question_id?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "gameone_user_help_attempts_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "gameone_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      gameone_user_progress: {
        Row: {
          completed_at: string | null
          id: number
          is_completed: boolean | null
          question_id: number | null
          user_id: string | null
        }
        Insert: {
          completed_at?: string | null
          id?: number
          is_completed?: boolean | null
          question_id?: number | null
          user_id?: string | null
        }
        Update: {
          completed_at?: string | null
          id?: number
          is_completed?: boolean | null
          question_id?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "gameone_user_progress_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "gameone_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      grades: {
        Row: {
          id: number
          name: string
        }
        Insert: {
          id?: number
          name: string
        }
        Update: {
          id?: number
          name?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          active: boolean
          created_at: string | null
          email: string | null
          firstname: string | null
          fullname: string | null
          grade_id: number | null
          id: string
          lastname: string | null
          middlename: string | null
          role: string
          section_id: number | null
          student_number: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string | null
          email?: string | null
          firstname?: string | null
          fullname?: string | null
          grade_id?: number | null
          id: string
          lastname?: string | null
          middlename?: string | null
          role?: string
          section_id?: number | null
          student_number?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string | null
          email?: string | null
          firstname?: string | null
          fullname?: string | null
          grade_id?: number | null
          id?: string
          lastname?: string | null
          middlename?: string | null
          role?: string
          section_id?: number | null
          student_number?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_grade_id_fkey"
            columns: ["grade_id"]
            isOneToOne: false
            referencedRelation: "grades"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "sections"
            referencedColumns: ["id"]
          },
        ]
      }
      pronunciations: {
        Row: {
          id: number
          pagbigkas: string
          picture: string | null
          recorded_audio: string | null
          tips: string[] | null
          word_ph: string
        }
        Insert: {
          id?: number
          pagbigkas: string
          picture?: string | null
          recorded_audio?: string | null
          tips?: string[] | null
          word_ph: string
        }
        Update: {
          id?: number
          pagbigkas?: string
          picture?: string | null
          recorded_audio?: string | null
          tips?: string[] | null
          word_ph?: string
        }
        Relationships: []
      }
      sections: {
        Row: {
          grade_id: number
          id: number
          name: string
        }
        Insert: {
          grade_id: number
          id?: number
          name: string
        }
        Update: {
          grade_id?: number
          id?: number
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "sections_grade_id_fkey"
            columns: ["grade_id"]
            isOneToOne: false
            referencedRelation: "grades"
            referencedColumns: ["id"]
          },
        ]
      }
      spelling_attempts: {
        Row: {
          attempt_number: number
          attempted_at: string | null
          guess: string
          id: number
          is_correct: boolean | null
          user_id: string
          word_id: string | null
        }
        Insert: {
          attempt_number: number
          attempted_at?: string | null
          guess: string
          id?: number
          is_correct?: boolean | null
          user_id: string
          word_id?: string | null
        }
        Update: {
          attempt_number?: number
          attempted_at?: string | null
          guess?: string
          id?: number
          is_correct?: boolean | null
          user_id?: string
          word_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "spelling_attempts_word_id_fkey"
            columns: ["word_id"]
            isOneToOne: false
            referencedRelation: "spelling_words"
            referencedColumns: ["id"]
          },
        ]
      }
      spelling_words: {
        Row: {
          category_id: number
          created_at: string | null
          hints: Json
          id: string
          max_attempts: number
          picture: string | null
          sort: number
          word: string
          word_en: string
        }
        Insert: {
          category_id: number
          created_at?: string | null
          hints?: Json
          id?: string
          max_attempts?: number
          picture?: string | null
          sort?: number
          word: string
          word_en: string
        }
        Update: {
          category_id?: number
          created_at?: string | null
          hints?: Json
          id?: string
          max_attempts?: number
          picture?: string | null
          sort?: number
          word?: string
          word_en?: string
        }
        Relationships: [
          {
            foreignKeyName: "spelling_words_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      user_scores: {
        Row: {
          game_mode: string
          id: number
          score: number
          updated_at: string
          user_id: string
        }
        Insert: {
          game_mode: string
          id?: number
          score?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          game_mode?: string
          id?: number
          score?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      vocabularies: {
        Row: {
          category_id: number | null
          color: string | null
          created_at: string | null
          example_word: string | null
          grade_id: number | null
          id: number
          letter_lower: string | null
          letter_upper: string | null
          meaning: string | null
          number: number | null
          picture: string | null
          section_id: number | null
          word: string
          word_en: string | null
        }
        Insert: {
          category_id?: number | null
          color?: string | null
          created_at?: string | null
          example_word?: string | null
          grade_id?: number | null
          id?: number
          letter_lower?: string | null
          letter_upper?: string | null
          meaning?: string | null
          number?: number | null
          picture?: string | null
          section_id?: number | null
          word: string
          word_en?: string | null
        }
        Update: {
          category_id?: number | null
          color?: string | null
          created_at?: string | null
          example_word?: string | null
          grade_id?: number | null
          id?: number
          letter_lower?: string | null
          letter_upper?: string | null
          meaning?: string | null
          number?: number | null
          picture?: string | null
          section_id?: number | null
          word?: string
          word_en?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vocabularies_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vocabularies_grade_id_fkey"
            columns: ["grade_id"]
            isOneToOne: false
            referencedRelation: "grades"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vocabularies_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "sections"
            referencedColumns: ["id"]
          },
        ]
      }
      word_of_the_day: {
        Row: {
          created_at: string | null
          date: string
          difficulty: string | null
          id: number
          phonetic: string | null
          picture: string | null
          tips: string | null
          word_en: string
          word_ph: string
        }
        Insert: {
          created_at?: string | null
          date: string
          difficulty?: string | null
          id?: number
          phonetic?: string | null
          picture?: string | null
          tips?: string | null
          word_en: string
          word_ph: string
        }
        Update: {
          created_at?: string | null
          date?: string
          difficulty?: string | null
          id?: number
          phonetic?: string | null
          picture?: string | null
          tips?: string | null
          word_en?: string
          word_ph?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_gameone_questions_with_lock: {
        Args: { user_uuid: string }
        Returns: {
          id: number
          is_completed: boolean
          level: number
          locked: boolean
        }[]
      }
      get_random_word_of_the_day: {
        Args: never
        Returns: {
          created_at: string
          date: string
          difficulty: string
          id: number
          phonetic: string
          picture: string
          tips: string
          word_en: string
          word_ph: string
        }[]
      }
      get_unanswered_spelling_words: {
        Args: { p_user_id: string }
        Returns: {
          category_id: number
          created_at: string | null
          hints: Json
          id: string
          max_attempts: number
          picture: string | null
          sort: number
          word: string
          word_en: string
        }[]
        SetofOptions: {
          from: "*"
          to: "spelling_words"
          isOneToOne: false
          isSetofReturn: true
        }
      }
    }
    Enums: {
      audit_action:
        | "INSERT"
        | "UPDATE"
        | "DELETE"
        | "LOGIN"
        | "LOGOUT"
        | "OTHER"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      audit_action: ["INSERT", "UPDATE", "DELETE", "LOGIN", "LOGOUT", "OTHER"],
    },
  },
} as const
