"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { redirect, usePathname } from "next/navigation";
import { User, Session } from "@supabase/supabase-js";
import { toast } from "sonner";
import { useAuthStore } from "@/stores/auth";
import { useLoadingStore } from "@/stores/loading";
import { supabase } from "@/lib/supabase/client";
import { Loading } from "@/components/loading";
import useAuditLogs from "@/hooks/useAuditLogs";
import ExpiredPage from "@/app/expired/page";

type AuthContextType = {
  user: User | null;
  session: Session | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

export const AuthContext = createContext<AuthContextType | undefined>(
  undefined,
);

const getUserAgent = (): string => {
  if (typeof window === "undefined") return "";

  const ua = navigator.userAgent;

  let browser = "Unknown Browser";
  let device = "Unknown Device";

  // Browser detection
  if (ua.includes("Chrome") && !ua.includes("Edg")) {
    browser = "Chrome";
  } else if (ua.includes("Safari") && !ua.includes("Chrome")) {
    browser = "Safari";
  } else if (ua.includes("Firefox")) {
    browser = "Firefox";
  } else if (ua.includes("Edg")) {
    browser = "Edge";
  }

  // Device / OS detection
  if (ua.includes("Mac OS X")) {
    device = "Mac";
  } else if (ua.includes("Windows")) {
    device = "Windows PC";
  } else if (ua.includes("Android")) {
    device = "Android";
  } else if (ua.includes("iPhone")) {
    device = "iPhone";
  } else if (ua.includes("iPad")) {
    device = "iPad";
  } else if (ua.includes("Linux")) {
    device = "Linux";
  }

  return `${device} • ${browser}`;
};

const getIP = async () => {
  const res = await fetch("https://api.ipify.org?format=json");
  const data = await res.json();
  return data.ip || "";
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [isDeploymentExpired, setIsDeploymentExpired] = useState(false);
  const {
    isAuthenticated,
    user,
    session,
    setSession,
    setUser,
    setProfile,
    reset,
    setIsAuthenticated,
  } = useAuthStore();
  const { isLoading, loadingOn, loadingOff } = useLoadingStore();
  const { logEvent } = useAuditLogs();
  const pathname = usePathname();

  const login = async (email: string, password: string) => {
    loadingOn();
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast.error(error.message || "Something went wrong.");
      loadingOff();
      // Insert a failed login attempt into audit_logs_v2
      await supabase.from("audit_logs_v2").insert([
        {
          actor_user_id: null, // unknown because login failed
          actor_email: email, // record the attempted email
          actor_role: "guest", // role for unauthenticated attempt
          target_user_id: null,
          action: "LOGIN",
          module: "auth",
          page: window.location.pathname,
          status: "error",
          description: "User login attempt failed.",
          ip_address: await getIP(),
          user_agent: getUserAgent(),
        },
      ]);
      return;
    }

    const user = data.user;

    const { data: userProfile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .maybeSingle();

    if (profileError || !userProfile) {
      toast.error("Failed to load user profile.");
      loadingOff();
      await logEvent(
        "LOGIN",
        user?.id,
        "auth",
        window.location.pathname,
        "error",
        "Failed to load user profile.",
      );
      logout();
    }

    if (!userProfile.active) {
      const message =
        "Your account is inactive. Please contact support for assistance.";
      toast.error(message);
      loadingOff();
      await logEvent(
        "LOGIN",
        user?.id,
        "auth",
        window.location.pathname,
        "error",
        "Account is inactive.",
      );
      logout();
    }

    setSession(data.session);
    setProfile(userProfile);
    setUser(user);
    setIsAuthenticated(true);
    toast.success("Login successful");
    await logEvent(
      "LOGIN",
      user?.id,
      "auth",
      window.location.pathname,
      "success",
      "User logged in",
    );

    loadingOff();
    redirect("/app/home");
  };

  const logout = async () => {
    loadingOn();

    const { error } = await supabase.auth.signOut();

    if (error) {
      toast.error(error.message || "Something went wrong.");
      await logEvent(
        "LOGOUT",
        user?.id,
        "auth",
        window.location.pathname,
        "error",
        "User logout attempt failed.",
      );
    } else {
      console.log("user", user);

      await logEvent(
        "LOGOUT",
        user?.id,
        "auth",
        window.location.pathname,
        "success",
        "User logged out",
      );
      reset();
      toast.success("Logged out successfully");
      loadingOff();
      redirect("/login");
    }

    loadingOff();
  };

  const initializeAuth = async () => {
    loadingOn();

    const { data } = await supabase.auth.getSession();
    const session = data.session;

    if (!session) {
      reset();
      loadingOff();
      return;
    }

    const user = session.user;

    // Get user profile from your 'profile' table
    const { data: userProfile, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .maybeSingle();

    if (error) {
      toast.error("Failed to fetch user profile.");
      await logEvent(
        "LOGIN",
        user?.id,
        "auth",
        window.location.pathname,
        "error",
        "Failed to load user profile.",
      );
      await supabase.auth.signOut();
      reset();
      loadingOff();
      redirect("/login");
    }

    if (userProfile && !userProfile.active) {
      toast.error("Your account is inactive.");
      await logEvent(
        "LOGIN",
        user?.id,
        "auth",
        window.location.pathname,
        "error",
        "Account is inactive.",
      );
      await supabase.auth.signOut();
      reset();
      loadingOff();
      redirect("/login");
    }

    if (userProfile && userProfile.role === "student") {
      toast.error("Your account not authorized to access this application.");
      await logEvent(
        "LOGIN",
        user?.id,
        "auth",
        window.location.pathname,
        "error",
        "Account is not authorized to access this application.",
      );
      await supabase.auth.signOut();
      reset();
      loadingOff();
      redirect("/login");
    }

    // Set auth state
    setProfile(userProfile);
    setSession(session);
    setUser(user);
    setIsAuthenticated(true);

    // Redirect only if not already on the correct dashboard
    const pathname = window.location.pathname;

    // Only redirect if user is on login or landing page
    const isOnPublicPage = ["/", "/login"].includes(pathname);

    if (isOnPublicPage) {
      loadingOff();
      redirect("/app/home");
    }

    loadingOff();
  };

  useEffect(() => {
    // Check if deployment has expired
    const expiryDateStr = process.env.NEXT_PUBLIC_DEPLOYMENT_EXPIRY_DATE;
    if (expiryDateStr) {
      const expiry = new Date(expiryDateStr);
      const now = new Date();
      if (now > expiry) {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        setIsDeploymentExpired(true);
      }
    }

    initializeAuth();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        loadingOff();
        reset();

        // if (!PUBLIC_ROUTES.includes(pathname)) {
        //   redirect("/login");
        // }

        if (["/"].includes(pathname)) {
          redirect("/login");
        }
      } else {
        setSession(session);
        setUser(session.user);
        setIsAuthenticated(true);
      }
    });

    return () => subscription.unsubscribe();
  }, [pathname]);

  // If deployment is expired, show expired page
  if (isDeploymentExpired) {
    return <ExpiredPage />;
  }

  return (
    <AuthContext.Provider
      value={{
        isLoading,
        user,
        session,
        isAuthenticated,
        login,
        logout,
      }}>
      {isLoading ? <Loading /> : children}
    </AuthContext.Provider>
  );
};

const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export default useAuth;
