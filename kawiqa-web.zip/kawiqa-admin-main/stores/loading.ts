"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

type LoadingStore = {
  isLoading: boolean;
  loadingOn: () => void;
  loadingOff: () => void;
};

export const useLoadingStore = create<LoadingStore>()(
  persist(
    set => ({
      isLoading: true,
      loadingOn: () => set({ isLoading: true }),
      loadingOff: () => set({ isLoading: false }),
    }),
    {
      name: "loading-storage",
    }
  )
);
