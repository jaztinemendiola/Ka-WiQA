"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { User, Session } from "@supabase/supabase-js";
import { Database } from "@/types/database.types";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];

type AuthStore = {
  user: User | null;
  profile: Profile | null;
  session: Session | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isTeacher: boolean;
  setProfile: (user: Profile | null) => void;
  setUser: (user: User | null) => void;
  setSession: (session: Session | null) => void;
  setIsAuthenticated: (isAuthenticated: boolean) => void;
  reset: () => void;
};

export const useAuthStore = create<AuthStore>()(
  persist(
    set => ({
      user: null,
      profile: null,
      session: null,
      isAuthenticated: false,
      isAdmin: false,
      isTeacher: false,
      setUser: user => set({ user }),
      setProfile: profile =>
        set({
          profile,
          isAdmin: profile?.role === "admin",
          isTeacher: profile?.role === "teacher",
        }),
      setSession: session => set({ session }),
      setIsAuthenticated: isAuthenticated => set({ isAuthenticated }),
      reset: () => set({ user: null, session: null, isAuthenticated: false }),
    }),
    {
      name: "auth-storage",
    },
  ),
);
